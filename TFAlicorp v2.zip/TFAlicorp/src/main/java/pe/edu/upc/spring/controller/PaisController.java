package pe.edu.upc.spring.controller;

import java.text.ParseException;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import pe.edu.upc.spring.model.Pais;
import pe.edu.upc.spring.service.IPaisService;

@Controller
@RequestMapping("/pais")
public class PaisController {

	@Autowired
	private IPaisService paisService;

	@RequestMapping("/")
	public String irPais(Map<String, Object> model) {
		model.put("listaPais", paisService.listar());
		return "/pais/listPais";
	}

	@RequestMapping("/irRegistrar")
	public String irRegistrar(Model model) {

		model.addAttribute("pais", new Pais());
		return "/pais/pais";
	}

	@RequestMapping("/registrar")
	public String registrar(@ModelAttribute @Valid Pais objPais, BindingResult binRes, Model model)
			throws ParseException {
		if (binRes.hasErrors()) {
			return "/pais/pais";
		} else {
			boolean flag = paisService.insertar(objPais);
			if (flag) {
				return "redirect:/pais/listar";
			} else {
				model.addAttribute("mensaje", "Ocurrió un error");
				return "redirect:/pais/irRegistrar";
			}
		}
	}

	@RequestMapping("/actualizar")
	public String actualizar(@ModelAttribute @Valid Pais objPais, BindingResult binRes, Model model,
			RedirectAttributes objRedir) throws ParseException {
		if (binRes.hasErrors()) {
			return "redirect:/pais/listar";
		} else {
			boolean flag = paisService.modificar(objPais);

			if (flag) {
				objRedir.addFlashAttribute("mensaje", "Se actualizó correctamente");
				return "redirect:/pais/listar";

			} else {
				objRedir.addFlashAttribute("mensaje", "Ocurrió un error");
				return "redirect:/pais/listar";
			}
		}
	}

	// El update
	@RequestMapping("/modificar/{id}")
	public String modificar(@PathVariable int id, Model model, RedirectAttributes objRedir) {
		Pais objPais = paisService.listarId(id);
		if (objPais == null) {
			objRedir.addFlashAttribute("mensaje", "Ocurrió un error");
			return "redirect:/pais/listar";
		} else {
			model.addAttribute("pais", objPais);
			return "/pais/pais";

		}

	}

	@RequestMapping("/eliminar")
	public String eliminar(Map<String, Object> model, @RequestParam(value = "id") Integer id) {
		try {
			if (id != null && id > 0) {
				paisService.eliminar(id);
				model.put("listaPais", paisService.listar());
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			model.put("mensaje", "No se puede eliminar una Raza asignada");
			model.put("listaPais", paisService.listar());

		}
		return "/pais/listPais";
	}

	@RequestMapping("/listar")
	public String listar(Map<String, Object> model) {

		model.put("listaPais", paisService.listar());
		return "/pais/listPais";

	}

	@RequestMapping("/listarId")
	public String listarId(Map<String, Object> model, @ModelAttribute Pais pais) {

		paisService.listarId(pais.getIdPais());
		return "/pais/listPais";

	}

	@RequestMapping("/irBuscar")
	public String irBuscar(Model model) {

		//model.addAttribute("pais", new Pais());
		return "redirect:/pais/listar";

	}

}
