package pe.edu.upc.spring.dao;
	
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import pe.edu.upc.spring.model.Cliente;
import pe.edu.upc.spring.model.Usuario;

@Repository
public interface IClienteDAO extends JpaRepository<Cliente, Integer>{
	
	@Query("from Cliente c where c.razon_social like %:razon_social%")
	List<Cliente> buscarNombre(@Param("razon_social")String Razon_social);
 	

	public Cliente findByUsuario(Usuario user);//busca por usuario del cliente
}
