package pe.edu.upc.spring.dao;
	
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import pe.edu.upc.spring.model.Detalle_pedido;

@Repository
public interface IDetalle_pedidoDAO extends JpaRepository<Detalle_pedido, Integer>{
	
	
}
