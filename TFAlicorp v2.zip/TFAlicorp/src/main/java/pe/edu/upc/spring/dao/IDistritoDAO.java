package pe.edu.upc.spring.dao;
	
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import pe.edu.upc.spring.model.Distrito;

@Repository
public interface IDistritoDAO extends JpaRepository<Distrito, Integer>{
	
	
}
