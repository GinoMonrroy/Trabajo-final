package pe.edu.upc.spring.dao;
	
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import pe.edu.upc.spring.model.Pais;

@Repository
public interface IPaisDAO extends JpaRepository<Pais, Integer>{
	
}
