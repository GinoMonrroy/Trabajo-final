package pe.edu.upc.spring.dao;
	
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import pe.edu.upc.spring.model.Usuario;

@Repository
public interface IUsuarioDAO extends JpaRepository<Usuario, Integer>{
	
	@Query("from Usuario c where c.username = :username")
	public Usuario buscarNombre(@Param("username")String username);
	
	//JPADETAIL
	@Query("from Usuario c where c.username like %:username%")
	public List<Usuario> listarxNombre(@Param("username")String username);

    @Modifying
	@Query(value = "insert into authorities (authority, user_id) VALUES (:authority, :user_id)", nativeQuery = true)
	public void insRol(@Param("authority") String authority, @Param("user_id") int user_id);
		
}
