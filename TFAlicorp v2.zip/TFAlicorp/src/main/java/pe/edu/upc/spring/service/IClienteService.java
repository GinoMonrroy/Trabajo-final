package pe.edu.upc.spring.service;

import java.util.List;

import pe.edu.upc.spring.model.Cliente;
import pe.edu.upc.spring.model.Usuario;

public interface IClienteService {

	public boolean insertar(Cliente cliente);

	public boolean modificar(Cliente cliente);

	public void eliminar(int idCliente);

	public Cliente listarId(int idCliente);

	List<Cliente> listar();

	List<Cliente> buscarNombre(String Razon_social);

	public Cliente buscarClienteporUsuario(Usuario user); 
}
