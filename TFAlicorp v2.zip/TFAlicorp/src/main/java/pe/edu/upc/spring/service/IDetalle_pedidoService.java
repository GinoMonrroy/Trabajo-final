package pe.edu.upc.spring.service;

import java.util.List;

import pe.edu.upc.spring.model.Detalle_pedido;

public interface IDetalle_pedidoService {


	public boolean insertar(Detalle_pedido detalle_pedido);

	public boolean modificar(Detalle_pedido detalle_pedido);

	public void eliminar(int idDetalle_pedido);

	public Detalle_pedido listarId(int idDetalle_pedido);

	List<Detalle_pedido> listar();

}
