package pe.edu.upc.spring.service;

import java.util.List;

import pe.edu.upc.spring.model.Pais;

public interface IPaisService {

	public boolean insertar(Pais pais);

	public boolean modificar(Pais pais);

	public void eliminar(int idPais);

	public Pais listarId(int idPais);

	List<Pais> listar();

}
