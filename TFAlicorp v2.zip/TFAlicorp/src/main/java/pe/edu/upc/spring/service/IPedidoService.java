package pe.edu.upc.spring.service;

import java.util.List;

import pe.edu.upc.spring.model.Cliente;
import pe.edu.upc.spring.model.Detalle_pedido;
import pe.edu.upc.spring.model.Pedido;

public interface IPedidoService {

	public boolean insertar(Pedido pedido);

	public boolean modificar(Pedido pedido);

	public void eliminar(int idPedido);

	public Pedido listarId(int idPedido);

	List<Pedido> listar();

	public List<Pedido> listarxCliente(Cliente c);
	
	public List<Detalle_pedido> buscarDetalle_pedido(int idPedido);
}
