package pe.edu.upc.spring.service;

import java.util.List;

import pe.edu.upc.spring.model.Usuario;

public interface IUsuarioService {

	public boolean insertar(Usuario usuario);

	public boolean modificar(Usuario usuario);

	public void eliminar(int idUsuario);

	public Usuario listarId(int idUsuario);

	public List<Usuario> listarxNombre(String Nombre);

	List<Usuario> listar();
	
	public Usuario BuscarPorNombre(String username);

	public void insRol(String authority, int user_id);

}
