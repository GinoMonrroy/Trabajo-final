package pe.edu.upc.spring.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import pe.edu.upc.spring.dao.IArticuloDAO;
import pe.edu.upc.spring.model.Articulo;
import pe.edu.upc.spring.service.IArticuloService;

@Service
public class ArticuloServiceImpl implements IArticuloService {

	@Autowired
	private IArticuloDAO dArticulo;

	@Override
	@Transactional
	public boolean insertar(Articulo articulo) {
		Articulo objArticulo = dArticulo.save(articulo);
		if (objArticulo == null) {
			return false;
		} else {
			return true;
		}
	}

	@Override
	@Transactional
	public boolean modificar(Articulo articulo) {
		boolean flag = false;
		try {
			dArticulo.save(articulo);
			flag = true;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return flag;
	}

	@Override
	@Transactional
	public void eliminar(int idArticulo) {

		dArticulo.delete(idArticulo);

	}

	
	@Override
	@Transactional(readOnly=true)
	public Articulo listarId(int idArticulo) {
		return dArticulo.findOne(idArticulo);
	}

	@Override
	@Transactional(readOnly=true)
	public List<Articulo> buscarNombre(String Nombre) {

		return dArticulo.buscarNombre(Nombre);

	}

	@Override
	@Transactional(readOnly=true)
	public List<Articulo> listar() {
		return dArticulo.findAll();
	}

}
