package pe.edu.upc.spring.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import pe.edu.upc.spring.dao.ICiudadDAO;
import pe.edu.upc.spring.model.Ciudad;
import pe.edu.upc.spring.service.ICiudadService;

@Service
public class CiudadServiceImpl implements ICiudadService {

	@Autowired
	private ICiudadDAO dCiudad;

	@Override
	@Transactional
	public boolean insertar(Ciudad ciudad) {
		Ciudad objCiudad = dCiudad.save(ciudad);
		if (objCiudad == null) {
			return false;
		} else {
			return true;
		}
	}

	@Override
	@Transactional
	public boolean modificar(Ciudad ciudad) {
		boolean flag = false;
		try {
			dCiudad.save(ciudad);
			flag = true;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return flag;
	}

	@Override
	@Transactional
	public void eliminar(int idCiudad) {

		dCiudad.delete(idCiudad);

	}

	
	@Override
	@Transactional(readOnly=true)
	public Ciudad listarId(int idCiudad) {
		return dCiudad.findOne(idCiudad);
	}


	@Override
	@Transactional(readOnly=true)
	public List<Ciudad> listar() {
		return dCiudad.findAll();
	}

}
