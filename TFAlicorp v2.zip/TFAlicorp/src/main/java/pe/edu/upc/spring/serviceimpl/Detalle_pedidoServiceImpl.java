package pe.edu.upc.spring.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import pe.edu.upc.spring.dao.IDetalle_pedidoDAO;
import pe.edu.upc.spring.model.Detalle_pedido;
import pe.edu.upc.spring.service.IDetalle_pedidoService;

@Service
public class Detalle_pedidoServiceImpl implements IDetalle_pedidoService {

	@Autowired
	private IDetalle_pedidoDAO dDetalle_pedido;

	@Override
	@Transactional
	public boolean insertar(Detalle_pedido detalle_pedido) {
		Detalle_pedido objDetalle_pedido = dDetalle_pedido.save(detalle_pedido);
		if (objDetalle_pedido == null) {
			return false;
		} else {
			return true;
		}
	}

	@Override
	@Transactional
	public boolean modificar(Detalle_pedido detalle_pedido) {
		boolean flag = false;
		try {
			dDetalle_pedido.save(detalle_pedido);
			flag = true;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return flag;
	}

	@Override
	@Transactional
	public void eliminar(int idDetalle_pedido) {

		dDetalle_pedido.delete(idDetalle_pedido);

	}

	
	@Override
	@Transactional(readOnly=true)
	public Detalle_pedido listarId(int idDetalle_pedido) {
		return dDetalle_pedido.findOne(idDetalle_pedido);
	}


	@Override
	@Transactional(readOnly=true)
	public List<Detalle_pedido> listar() {
		return dDetalle_pedido.findAll();
	}

}
