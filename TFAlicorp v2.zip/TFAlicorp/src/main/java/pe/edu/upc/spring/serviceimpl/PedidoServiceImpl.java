package pe.edu.upc.spring.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import pe.edu.upc.spring.dao.IPedidoDAO;
import pe.edu.upc.spring.model.Cliente;
import pe.edu.upc.spring.model.Detalle_pedido;
import pe.edu.upc.spring.model.Pedido;
import pe.edu.upc.spring.service.IPedidoService;

@Service
public class PedidoServiceImpl implements IPedidoService {

	@Autowired
	private IPedidoDAO dPedido;

	@Override
	@Transactional
	public boolean insertar(Pedido pedido) {
		Pedido objPedido = dPedido.save(pedido);
		if (objPedido == null) {
			return false;
		} else {
			return true;
		}
	}

	@Override
	@Transactional
	public boolean modificar(Pedido pedido) {
		boolean flag = false;
		try {
			dPedido.save(pedido);
			flag = true;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return flag;
	}

	@Override
	@Transactional
	public void eliminar(int idPedido) {

		dPedido.delete(idPedido);

	}

	
	@Override
	@Transactional(readOnly=true)
	public Pedido listarId(int idPedido) {
		return dPedido.findOne(idPedido);
	}


	public List<Pedido> listarxCliente(Cliente c)
	{
		return dPedido.findByCliente(c);
	}

	@Override
	@Transactional(readOnly=true)
	public List<Pedido> listar() {
		return dPedido.findAll();
	}
	

	@Override
	@Transactional(readOnly=true)
	public List<Detalle_pedido> buscarDetalle_pedido(int idPedido) {

		return dPedido.buscarDetalle_pedido(idPedido);

	}

}
