package pe.edu.upc.spring.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import pe.edu.upc.spring.dao.IUsuarioDAO;
import pe.edu.upc.spring.model.Usuario;
import pe.edu.upc.spring.service.IUsuarioService;

@Service
public class UsuarioServiceImpl implements IUsuarioService {

	@Autowired
	private IUsuarioDAO dUsuario;

	@Override
	@Transactional
	public boolean insertar(Usuario race) {
		Usuario objUsuario = dUsuario.save(race);
		if (objUsuario == null) {
			return false;
		} else {
			return true;
		}
	}

	@Override
	@Transactional
	public boolean modificar(Usuario race) {
		boolean flag = false;
		try {
			dUsuario.save(race);
			flag = true;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return flag;
	}

	@Override
	@Transactional
	public void eliminar(int idUsuario) {

		dUsuario.delete(idUsuario);

	}
	
	@Override
	@Transactional(readOnly=true)
	public Usuario listarId(int idUsuario) {
		return dUsuario.findOne(idUsuario);
	}

	@Override
	@Transactional(readOnly=true)
	public List<Usuario> listarxNombre(String Nombre) {

		return dUsuario.listarxNombre(Nombre);

	}
	@Override
	@Transactional(readOnly=true)
	public Usuario BuscarPorNombre(String username) {

		return dUsuario.buscarNombre(username);

	}
	
	@Override
	@Transactional(readOnly=true)
	public List<Usuario> listar() {
		return dUsuario.findAll();
	}

	@Override
	@Transactional
	public void insRol(String authority, int user_id)
	{
		dUsuario.insRol(authority, user_id);
	}

}
