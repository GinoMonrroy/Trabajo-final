package pe.edu.upc.spring.controller;

import java.io.IOException;
import java.net.MalformedURLException;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import pe.edu.upc.spring.model.Articulo;
import pe.edu.upc.spring.service.IArticuloService;
import pe.edu.upc.spring.service.IUploadFileService;

@Controller
@RequestMapping("/articulo")
public class ArticuloController{

	
	@Autowired
	private IArticuloService articuloService;


	@Autowired
	private IUploadFileService uploadFileService;

	@GetMapping(value = "/uploads/{filename:.+}")
	public ResponseEntity<Resource> verFoto(@PathVariable String filename) {

		Resource recurso = null;

		try {
			recurso = uploadFileService.load(filename);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return ResponseEntity.ok()
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + recurso.getFilename() + "\"")
				.body(recurso);
	}
	
	@RequestMapping("/")
	public String irArticulo(Map<String, Object> model) {
		model.put("listaArticulos", articuloService.listar());
		return "/articulo/listArticulo";
	}

	@RequestMapping("/irRegistrar")
	public String irRegistrar(Model model) {

		model.addAttribute("articulo", new Articulo());
		return "/articulo/articulo";
	}

	@RequestMapping("/registrar")
	public String registrar(@ModelAttribute @Valid Articulo objArticulo, BindingResult binRes, Model model, @RequestParam("file") MultipartFile foto
			, RedirectAttributes flash)
			throws ParseException {
		if (binRes.hasErrors()) {
			return "/articulo/articulo";
		} else {
			
			if (!foto.isEmpty()) {

				if (objArticulo.getIdArticulo() != 0 && objArticulo.getIdArticulo() > 0 && objArticulo.getFoto() != null
						&& objArticulo.getFoto().length() > 0) {

					uploadFileService.delete(objArticulo.getFoto());
				}

				////
				String uniqueFilename = null;
				try {
					uniqueFilename = uploadFileService.copy(foto);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				flash.addFlashAttribute("info", "Has subido correctamente '" + uniqueFilename + "'");
				// pasar el nombre de la Foto al Empleado
				objArticulo.setFoto(uniqueFilename);

			}

			boolean flag = articuloService.insertar(objArticulo);
			if (flag) {
				return "redirect:/articulo/listar";
			} else {
				model.addAttribute("mensaje", "Ocurrió un error");
				return "redirect:/articulo/irRegistrar";
			}
		}
	}

	@RequestMapping("/actualizar")
	public String actualizar(@ModelAttribute @Valid Articulo objArticulo, BindingResult binRes, Model model,
			RedirectAttributes objRedir) throws ParseException {
		if (binRes.hasErrors()) {
			return "redirect:/articulo/listar";
		} else {
			boolean flag = articuloService.modificar(objArticulo);

			if (flag) {
				objRedir.addFlashAttribute("mensaje", "Se actualizó correctamente");
				return "redirect:/articulo/listar";

			} else {
				objRedir.addFlashAttribute("mensaje", "Ocurrió un error");
				return "redirect:/articulo/listar";
			}
		}
	}

	// El update
	@RequestMapping("/modificar/{id}")
	public String modificar(@PathVariable int id, Model model, RedirectAttributes objRedir) {
		Articulo objArticulo = articuloService.listarId(id);
		if (objArticulo == null) {
			objRedir.addFlashAttribute("mensaje", "Ocurrió un error");
			return "redirect:/pet/listar";
		} else {
			model.addAttribute("articulo", objArticulo);
			return "/articulo/articulo";

		}

	}

	
	@RequestMapping("/eliminar")
	public String eliminar(Map<String, Object> model, @RequestParam(value = "id") Integer id) {
		try {
			if (id != null && id > 0) {
				articuloService.eliminar(id);
				model.put("listaArticulos", articuloService.listar());
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			model.put("mensaje", "No se puede eliminar el elemento asignado");
			model.put("listaArticulos", articuloService.listar());

		}
		return "/articulo/listArticulo";
	}

	@RequestMapping("/listar")
	public String listar(Map<String, Object> model) {

		model.put("listaArticulos", articuloService.listar());
		return "/articulo/listArticulo";

	}

	@RequestMapping("/listarId")
	public String listarId(Map<String, Object> model, @ModelAttribute Articulo articulo) {

		articuloService.listarId(articulo.getIdArticulo());
		return "/articulo/listArticulo";

	}

	@RequestMapping("/buscar")
	public String buscar(Map<String, Object> model, @ModelAttribute Articulo articulo) throws ParseException {

		List<Articulo> listaArticulos;

		articulo.setNombre(articulo.getNombre());
		listaArticulos = articuloService.buscarNombre(articulo.getNombre());

		if (listaArticulos.isEmpty()) {

			model.put("mensaje", "No se encontró");
		}

		model.put("listaArticulos", listaArticulos);
		return "/articulo/buscarArticulo";

	}

	@RequestMapping("/irBuscar")
	public String irBuscar(Model model) {
		
		model.addAttribute("listaArticulos", articuloService.listar());
		model.addAttribute("articulo", new Articulo());
		return "/articulo/buscarArticulo";

	}

}
