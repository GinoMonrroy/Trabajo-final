package pe.edu.upc.spring.controller;

import java.net.MalformedURLException;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping; // simplifica codigo
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import pe.edu.upc.spring.model.Cliente;
import pe.edu.upc.spring.model.Usuario;
import pe.edu.upc.spring.service.ICiudadService;
import pe.edu.upc.spring.service.IClienteService;
import pe.edu.upc.spring.service.IDistritoService;
import pe.edu.upc.spring.service.IPaisService;
import pe.edu.upc.spring.service.IUploadFileService;
import pe.edu.upc.spring.service.IUsuarioService;

@Controller
@RequestMapping("/cliente")
public class ClienteController {

	@Autowired
	private BCryptPasswordEncoder passwordEncoder;

	@Autowired
	private IClienteService clienteService;

	@Autowired
	private IUsuarioService usuarioService;

	@Autowired
	private IPaisService paisService;
	@Autowired
	private IDistritoService distritoService;
	@Autowired
	private ICiudadService ciudadService;
	
	@Autowired
	private IUploadFileService uploadFileService;

	@GetMapping(value = "/uploads/{filename:.+}")
	public ResponseEntity<Resource> verFoto(@PathVariable String filename) {

		Resource recurso = null;

		try {
			recurso = uploadFileService.load(filename);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return ResponseEntity.ok()
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + recurso.getFilename() + "\"")
				.body(recurso);
	}
	

	@RequestMapping("/")
	public String irCliente(Map<String, Object> model) {
		model.put("listaClientes", clienteService.listar());
		return "/cliente/listCliente";
	}

	@RequestMapping("/irRegistrar")
	public String irRegistrar(Model model) {

		model.addAttribute("cliente", new Cliente());
		model.addAttribute("listapais", paisService.listar());
		model.addAttribute("listaciudad", ciudadService.listar());
		model.addAttribute("listadistrito", distritoService.listar());
		return "/cliente/cliente";
	}

	@RequestMapping("/registrar")
	public String registrar(@ModelAttribute @Valid Cliente objCliente, BindingResult binRes, Model model)
			throws ParseException {
		if (binRes.hasErrors()) {
			model.addAttribute("listapais", paisService.listar());
			model.addAttribute("listaciudad", ciudadService.listar());
			model.addAttribute("listadistrito", distritoService.listar());
			return "/cliente/cliente";
		} else {

			Usuario aux = new Usuario();
			aux.setUsername(objCliente.getUsuario().getUsername());
			aux.setPassword(objCliente.getUsuario().getPassword());
			aux.setEnabled(true);

			String bcryptPassword = passwordEncoder.encode(aux.getPassword());
			aux.setPassword(bcryptPassword);
			usuarioService.insertar(aux);

			aux = usuarioService.BuscarPorNombre(objCliente.getUsuario().getUsername());

			usuarioService.insRol("ROLE_USER", aux.getId());

			objCliente.setUsuario(aux);
			
			boolean flag = clienteService.insertar(objCliente);
			if (flag) {
				return "redirect:/login/";
			} else {
				model.addAttribute("mensaje", "Ocurrió un error");
				return "redirect:/cliente/irRegistrar";
			}
		}
	}

	@RequestMapping("/actualizar")
	public String actualizar(@ModelAttribute @Valid Cliente objCliente, BindingResult binRes, Model model,
			RedirectAttributes objRedir) throws ParseException {
		if (binRes.hasErrors()) {
			model.addAttribute("listapais", paisService.listar());
			model.addAttribute("listaciudad", ciudadService.listar());
			model.addAttribute("listadistrito", distritoService.listar());
			return "redirect:/cliente/listar";
		} else {
			Usuario aux = new Usuario();
			aux.setUsername(objCliente.getUsuario().getUsername());
			aux.setPassword(objCliente.getUsuario().getPassword());
			aux.setEnabled(true);

			String bcryptPassword = passwordEncoder.encode(aux.getPassword());
			aux.setPassword(bcryptPassword);
			usuarioService.modificar(aux);
			
			objCliente.setUsuario(aux);
		
			boolean flag = clienteService.modificar(objCliente);

			if (flag) {
				objRedir.addFlashAttribute("mensaje", "Se actualizó correctamente");
				return "redirect:/cliente/listar";

			} else {
				objRedir.addFlashAttribute("mensaje", "Ocurrió un error");
				return "redirect:/cliente/listar";
			}
		}
	}

	// El update
	@RequestMapping("/modificar/{id}")
	public String modificar(@PathVariable int id, Model model, RedirectAttributes objRedir) {

		model.addAttribute("listapais", paisService.listar());
		model.addAttribute("listaciudad", ciudadService.listar());
		model.addAttribute("listadistrito", distritoService.listar());
		Cliente objCliente = clienteService.listarId(id);
		if (objCliente == null) {
			objRedir.addFlashAttribute("mensaje", "Ocurrió un error");
			return "redirect:/cliente/listar";
		} else {
			model.addAttribute("cliente", objCliente);
			return "/cliente/cliente";

		}

	}

	@RequestMapping("/eliminar")
	public String eliminar(Map<String, Object> model, @RequestParam(value = "id") Integer id) {
		try {
			if (id != null && id > 0) {
				clienteService.eliminar(id);
				model.put("listaClientes", clienteService.listar());
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			model.put("mensaje", "No se puede eliminar una Raza asignada");
			model.put("listaClientes", clienteService.listar());

		}
		return "/cliente/listCliente";
	}

	@RequestMapping("/listar")
	public String listar(Map<String, Object> model) {

		model.put("listaClientes", clienteService.listar());
		return "/cliente/listCliente";

	}

	@RequestMapping("/listarId")
	public String listarId(Map<String, Object> model, @ModelAttribute Cliente cliente) {

		clienteService.listarId(cliente.getIdCliente());
		return "/cliente/listCliente";

	}

	@RequestMapping("/buscar")
	public String buscar(Map<String, Object> model, @ModelAttribute Cliente cliente) throws ParseException {

		List<Cliente> listaClientes;

		cliente.setRazon_social(cliente.getRazon_social());
		listaClientes = clienteService.buscarNombre(cliente.getRazon_social());

		if (listaClientes.isEmpty()) {

			model.put("mensaje", "No se encontró");
		}

		model.put("listaClientes", listaClientes);
		return "/cliente/buscarCliente";

	}

	@RequestMapping("/irBuscar")
	public String irBuscar(Model model) {

		model.addAttribute("cliente", new Cliente());
		return "/cliente/buscarCliente";

	}

}
