package pe.edu.upc.spring.controller;

import java.text.ParseException;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import pe.edu.upc.spring.model.Articulo;
import pe.edu.upc.spring.model.Detalle_pedido;
import pe.edu.upc.spring.model.Pedido;
import pe.edu.upc.spring.service.IArticuloService;
import pe.edu.upc.spring.service.IDetalle_pedidoService;
import pe.edu.upc.spring.service.IPedidoService;

@Controller
@RequestMapping("/detalle_pedido")
public class Detalle_pedidoController {

	@Autowired
	private IDetalle_pedidoService detalle_pedidoService;
	@Autowired
	private IArticuloService articuloService;
	@Autowired
	private IPedidoService pedidoService;

	// @Autowired
	// private IUsuarioService uService;
	@RequestMapping("/")
	public String irDetalle_pedido(Map<String, Object> model) {
		model.put("listaDetalle_pedidos", detalle_pedidoService.listar());
		return "/pedido/listDetalle_pedido";
	}

	@RequestMapping("/irRegistrar/{id}")
	public String irRegistrar(@PathVariable int id, Model model) {

		model.addAttribute("listaArticulo", articuloService.listar());
		model.addAttribute("listaPedido", pedidoService.listar());
		Detalle_pedido dp = new Detalle_pedido();
		Pedido p = pedidoService.listarId(id);
		dp.setPedido(p);
		model.addAttribute("detalle_pedido", dp);
		return "/pedido/detalle_pedido";
	}
	
	@RequestMapping("/seleccionar/{idPedido}/{idArticulo}")
	public String seleccionar(@PathVariable("idPedido") int idPedido, @PathVariable("idArticulo") int idArticulo, Model model) {

		model.addAttribute("listaArticulo", articuloService.listar());
		model.addAttribute("listaPedido", pedidoService.listar());
		Detalle_pedido dp = new Detalle_pedido();
		Pedido p = pedidoService.listarId(idPedido);

		Articulo art = articuloService.listarId(idArticulo);
		dp.setArticulo(art);
		dp.setPedido(p);
		model.addAttribute("detalle_pedido", dp);
		return "/pedido/detalle_pedido";
	}

	

	@RequestMapping("/registrar")
	public String registrar(@ModelAttribute @Valid Detalle_pedido objDetalle_pedido, BindingResult binRes, Model model)
			throws ParseException {
		if (binRes.hasErrors()) {

			model.addAttribute("listaArticulo", articuloService.listar());
			model.addAttribute("listaPedido", pedidoService.listar());
			return "/pedido/detalle_pedido";
		} else {
			boolean flag = detalle_pedidoService.insertar(objDetalle_pedido);
			if (flag) {
				return "redirect:/pedido/detalles/" + objDetalle_pedido.getPedido().getIdPedido();
			} else {
				model.addAttribute("mensaje", "Ocurrió un error");
				return "redirect:/detalle_pedido/irRegistrar";
			}
		}
	}

	@RequestMapping("/actualizar")
	public String actualizar(@ModelAttribute @Valid Detalle_pedido objDetalle_pedido, BindingResult binRes, Model model,
			RedirectAttributes objRedir) throws ParseException {
		if (binRes.hasErrors()) {
			return "redirect:/detalle_pedido/listar";
		} else {

			model.addAttribute("listaArticulo", articuloService.listar());
			model.addAttribute("listaPedido", pedidoService.listar());
			boolean flag = detalle_pedidoService.modificar(objDetalle_pedido);

			if (flag) {
				objRedir.addFlashAttribute("mensaje", "Se actualizó correctamente");
				return "redirect:/pedido/detalles/" + objDetalle_pedido.getPedido().getIdPedido();

			} else {
				objRedir.addFlashAttribute("mensaje", "Ocurrió un error");
				return "redirect:/pedido/detalles/" + objDetalle_pedido.getPedido().getIdPedido();
			}
		}
	}

	// El update
	@RequestMapping("/modificar/{id}")
	public String modificar(@PathVariable int id, Model model, RedirectAttributes objRedir) {

		model.addAttribute("listaArticulo", articuloService.listar());
		model.addAttribute("listaPedido", pedidoService.listar());
		Detalle_pedido objDetalle_pedido = detalle_pedidoService.listarId(id);
		if (objDetalle_pedido == null) {

			objRedir.addFlashAttribute("mensaje", "Ocurrió un error");
			return "redirect:/pedido/listar";
		} else {
			model.addAttribute("detalle_pedido", objDetalle_pedido);
			return "/pedido/detalle_pedido";

		}

	}

	@RequestMapping(value = "/eliminar/{id}")
	public String eliminar(@PathVariable(value = "id") Integer id,
			RedirectAttributes flash) {

		Detalle_pedido objPedido = detalle_pedidoService.listarId(id);
		if (id != null && id > 0) {
			detalle_pedidoService.eliminar(id);
					
			
		}
		return "redirect:/pedido/detalles/" + objPedido.getPedido().getIdPedido();
	}


	@RequestMapping("/listar")
	public String listar(Map<String, Object> model) {
		/*
		 * Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		 * Object principal = auth.getPrincipal(); String name = principal.toString();
		 * if(principal instanceof UserDetails) { name =
		 * ((UserDetails)principal).getUsername(); }else { name = principal.toString();
		 * }
		 * 
		 * Usuario u = uService.BuscarPorNombre(name); model.put("rol", u.getRoles());
		 */
		model.put("listaDetalle_pedidos", detalle_pedidoService.listar());

		return "/pedido/listDetalle_Pedido";

	}

	@RequestMapping("/listarId")
	public String listarId(Map<String, Object> model, @ModelAttribute Detalle_pedido detalle_pedido) {

		detalle_pedidoService.listarId(detalle_pedido.getIdDetalle_Pedido());
		return "/pedido/listDetalle_pedido";

	}

	@RequestMapping("/irBuscar")
	public String irBuscar(Model model) {
		
		model.addAttribute("detalle_pedido", new Detalle_pedido());
		return "/pedido/buscarDetalle_pedido";

	}

}
