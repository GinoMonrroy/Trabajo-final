package pe.edu.upc.spring.controller;

import java.text.ParseException;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import pe.edu.upc.spring.model.Distrito;
import pe.edu.upc.spring.service.IDistritoService;

@Controller
@RequestMapping("/distrito")
public class DistritoController {

	@Autowired
	private IDistritoService distritoService;

	@RequestMapping("/")
	public String irDistrito(Map<String, Object> model) {
		model.put("listaDistritos", distritoService.listar());
		return "/distrito/listDistrito";
	}

	@RequestMapping("/irRegistrar")
	public String irRegistrar(Model model) {

		model.addAttribute("distrito", new Distrito());
		return "/distrito/distrito";
	}

	@RequestMapping("/registrar")
	public String registrar(@ModelAttribute @Valid Distrito objDistrito, BindingResult binRes, Model model)
			throws ParseException {
		if (binRes.hasErrors()) {
			return "/distrito/distrito";
		} else {
			boolean flag = distritoService.insertar(objDistrito);
			if (flag) {
				return "redirect:/distrito/listar";
			} else {
				model.addAttribute("mensaje", "Ocurrió un error");
				return "redirect:/distrito/irRegistrar";
			}
		}
	}

	@RequestMapping("/actualizar")
	public String actualizar(@ModelAttribute @Valid Distrito objDistrito, BindingResult binRes, Model model,
			RedirectAttributes objRedir) throws ParseException {
		if (binRes.hasErrors()) {
			return "redirect:/distrito/listar";
		} else {
			boolean flag = distritoService.modificar(objDistrito);

			if (flag) {
				objRedir.addFlashAttribute("mensaje", "Se actualizó correctamente");
				return "redirect:/distrito/listar";

			} else {
				objRedir.addFlashAttribute("mensaje", "Ocurrió un error");
				return "redirect:/distrito/listar";
			}
		}
	}

	// El update
	@RequestMapping("/modificar/{id}")
	public String modificar(@PathVariable int id, Model model, RedirectAttributes objRedir) {
		Distrito objDistrito = distritoService.listarId(id);
		if (objDistrito == null) {
			objRedir.addFlashAttribute("mensaje", "Ocurrió un error");
			return "redirect:/pet/listar";
		} else {
			model.addAttribute("distrito", objDistrito);
			return "/distrito/distrito";

		}

	}

	@RequestMapping("/eliminar")
	public String eliminar(Map<String, Object> model, @RequestParam(value = "id") Integer id) {
		try {
			if (id != null && id > 0) {
				distritoService.eliminar(id);
				model.put("listaDistritos", distritoService.listar());
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			model.put("mensaje", "No se puede eliminar una Raza asignada");
			model.put("listaDistritos", distritoService.listar());

		}
		return "/distrito/listDistrito";
	}

	@RequestMapping("/listar")
	public String listar(Map<String, Object> model) {

		model.put("listaDistritos", distritoService.listar());
		return "/distrito/listDistrito";

	}

	@RequestMapping("/listarId")
	public String listarId(Map<String, Object> model, @ModelAttribute Distrito distrito) {

		distritoService.listarId(distrito.getIdDistrito());
		return "/distrito/listDistrito";

	}

	@RequestMapping("/irBuscar")
	public String irBuscar(Model model) {

		//model.addAttribute("distrito", new Distrito());
		return "/distrito/listDistrito";

	}

}
