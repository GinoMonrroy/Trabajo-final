package pe.edu.upc.spring.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import pe.edu.upc.spring.model.Cliente;
import pe.edu.upc.spring.model.Detalle_pedido;
import pe.edu.upc.spring.model.Pedido;
import pe.edu.upc.spring.model.Usuario;
import pe.edu.upc.spring.service.IClienteService;
import pe.edu.upc.spring.service.IPedidoService;
import pe.edu.upc.spring.service.IUsuarioService;

@Controller
@RequestMapping("/pedido")
@SessionAttributes
public class PedidoController {

	// MEMO: VER FLASHATTRIBUTES :'L
	@Autowired
	private IPedidoService pedidoService;

	@Autowired
	private IUsuarioService uService;

	@Autowired
	private IClienteService cService;

	@RequestMapping("/")
	public String irPedido(Map<String, Object> model) {
		model.put("listaPedidos", pedidoService.listar());
		return "listPedido";
	}

	@RequestMapping("/irRegistrar")
	public String irRegistrar(Model model) throws ParseException {

		Pedido p = new Pedido();
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDateTime now = LocalDateTime.now();
		String str = now.format(dtf);
		Date fecha = new SimpleDateFormat("yyyy-MM-dd").parse(str);
		p.setFechaGenerada(fecha);
		
		model.addAttribute("pedido", p);
		return "/pedido/pedido";
	}

	@RequestMapping("/registrar")
	public String registrar(@ModelAttribute @Valid Pedido objPedido, BindingResult binRes, Model model)
			throws ParseException {
		if (binRes.hasErrors()) {
			return "/pedido/pedido";
		} else {
			if (objPedido.getForma_Pago() == 0) {
				objPedido.setCondicional_Pago(0);
			}
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			Object principal = auth.getPrincipal();
			String name = principal.toString();
			if (principal instanceof UserDetails) {
				name = ((UserDetails) principal).getUsername();
			} else {
				name = principal.toString();
			}

			Usuario u = uService.BuscarPorNombre(name);
			Cliente c = cService.buscarClienteporUsuario(u);

			objPedido.setCliente(c);
			objPedido.setEstado(0);

			boolean flag = pedidoService.insertar(objPedido);
			if (flag) {
				return "redirect:/pedido/listar";
			} else {
				model.addAttribute("mensaje", "Ocurrió un error");
				return "redirect:/pedido/irRegistrar";
			}
		}
	}

	@RequestMapping("/actualizar")
	public String actualizar(@ModelAttribute @Valid Pedido objPedido, BindingResult binRes, Model model,
			RedirectAttributes objRedir) throws ParseException {
		if (binRes.hasErrors()) {
			return "redirect:/pedido/listar";
		} else {

			boolean flag = pedidoService.modificar(objPedido);

			if (flag) {
				objRedir.addFlashAttribute("mensaje", "Se actualizó correctamente");
				return "redirect:/pedido/listar";

			} else {
				objRedir.addFlashAttribute("mensaje", "Ocurrió un error");
				return "redirect:/pedido/listar";
			}
		}
	}

	// El update
	@RequestMapping("/modificar/{id}")
	public String modificar(@PathVariable int id, Model model, RedirectAttributes objRedir) {
		Pedido objPedido = pedidoService.listarId(id);
		if (objPedido == null) {
			objRedir.addFlashAttribute("mensaje", "Ocurrió un error");
			return "redirect:/pedido/listar";
		} else {
			model.addAttribute("pedido", objPedido);
			return "/pedido/pedido";
		}

	}

	@RequestMapping("/eliminar/{id}")
	public String eliminar(Map<String, Object> model, @PathVariable int id) {
		try {
			if (id > 0) {
				pedidoService.eliminar(id);
				model.put("listaPedidos", pedidoService.listar());
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			model.put("mensaje", "No se puede eliminar una Raza asignada");
			model.put("listaPedidos", pedidoService.listar());

		}
		return "redirect:/pedido/listar";
	}

	@RequestMapping("/listar")
	public String listar(Map<String, Object> model) {

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		Object principal = auth.getPrincipal();
		String name = principal.toString();
		if (principal instanceof UserDetails) {
			name = ((UserDetails) principal).getUsername();
		} else {
			name = principal.toString();
		}

		Usuario u = uService.BuscarPorNombre(name);
		Cliente c = cService.buscarClienteporUsuario(u);

		List<Pedido> pedidoxcliente = pedidoService.listarxCliente(c);

		model.put("listaPedidos", pedidoxcliente);
		return "/pedido/listPedido";

	}

	@RequestMapping("/listartodos")
	public String listartodos(Map<String, Object> model) {

		model.put("listaPedidos", pedidoService.listar());
		return "/pedido/listPedidotodos";

	}

	@RequestMapping("/listarnoatendidos")
	public String listarnoatendidos(Map<String, Object> model) {

		// Usuario u = uService.BuscarPorNombre("admin");

		List<Pedido> pedidonoatendido = new ArrayList<Pedido>();
		for (Pedido p : pedidoService.listar()) {
			if (p.getEstado() == 0) {
				pedidonoatendido.add(p);
			}
		}

		model.put("listaPedidos", pedidonoatendido);
		return "/pedido/listPedidonoat";

	}

	// El update
	@RequestMapping("/atender/{id}")
	public String atender(@PathVariable int id, Model model, RedirectAttributes objRedir) {
		Pedido objPedido = pedidoService.listarId(id);

		objPedido.setEstado(1);
		boolean flag = pedidoService.modificar(objPedido);

		if (flag) {
			objRedir.addFlashAttribute("mensaje", "Se actualizó correctamente");
			return "redirect:/pedido/listartodos";

		} else {
			objRedir.addFlashAttribute("mensaje", "Ocurrió un error");
			return "redirect:/pedido/listarnoatendidos";
		}

	}

	@RequestMapping("/listarId")
	public String listarId(Map<String, Object> model, @ModelAttribute Pedido pedido) {

		pedidoService.listarId(pedido.getIdPedido());
		return "/pedido/listPedido";

	}

	@RequestMapping("/irBuscar")
	public String irBuscar(Model model) {

		model.addAttribute("pedido", new Pedido());
		return "/pedido/buscar";

	}

	@RequestMapping("/detalles/{id}")
	public String listarDetalles(@PathVariable int id, Map<String, Object> model, RedirectAttributes objRedir) {

		Pedido objPedido = pedidoService.listarId(id);
		model.put("pedido", objPedido);
		model.put("idPedido", objPedido.getIdPedido());
		model.put("listaDetalles", pedidoService.buscarDetalle_pedido(id));

		double total = 0;
		for (Detalle_pedido dp : pedidoService.buscarDetalle_pedido(id)) {
			total += dp.getArticulo().getPrecio() * dp.getCantidad();
		}
		model.put("total", total);
		return "/pedido/listDetalle_Pedido";

	}

	@RequestMapping("/seleccionar/{id}")
	public String listarPedidoxCliente(@PathVariable int id, Map<String, Object> model, RedirectAttributes objRedir) {

		Cliente c = cService.listarId(id);
		List<Pedido> pedidoxcliente = pedidoService.listarxCliente(c);

		model.put("listaPedidos", pedidoxcliente);
		return "/pedido/listPxC";

	}

	@RequestMapping("/irlistarpxc")
	public String irlistarpxc(Model model) throws ParseException {
		
		model.addAttribute("cliente", new Cliente());
		model.addAttribute("listacliente", cService.listar());
		return "/pedido/listPedidoxCliente";
	}
	
	
	
	
	
	@RequestMapping("/detallesxCliente/{id}")
	public String listarDetallesxCliente(@PathVariable int id, Map<String, Object> model, RedirectAttributes objRedir) {

		Pedido objPedido = pedidoService.listarId(id);
		model.put("pedido", objPedido);
		model.put("idPedido", objPedido.getIdPedido());
		model.put("listaDetalles", pedidoService.buscarDetalle_pedido(id));

		double total = 0;
		for (Detalle_pedido dp : pedidoService.buscarDetalle_pedido(id)) {
			total += dp.getArticulo().getPrecio() * dp.getCantidad();
		}
		model.put("total", total);
		return "/pedido/listDetalle_PedidoxCliente";

	}
}
