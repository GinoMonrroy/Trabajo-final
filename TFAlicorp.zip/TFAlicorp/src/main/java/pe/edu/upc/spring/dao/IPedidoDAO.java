package pe.edu.upc.spring.dao;
	
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import pe.edu.upc.spring.model.Cliente;
import pe.edu.upc.spring.model.Detalle_pedido;
import pe.edu.upc.spring.model.Pedido;

@Repository
public interface IPedidoDAO extends JpaRepository<Pedido, Integer>{
	
	public List<Pedido> findByCliente(Cliente c);

	@Query("from Detalle_pedido p where p.pedido.idPedido = :idPedido")
	public List<Detalle_pedido> buscarDetalle_pedido(@Param("idPedido") int idPedido);
}
