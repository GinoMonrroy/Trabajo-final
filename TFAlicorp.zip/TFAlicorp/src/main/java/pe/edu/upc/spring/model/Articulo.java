package pe.edu.upc.spring.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Min;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name = "articulo")
public class Articulo implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idArticulo;
	
	@NotBlank(message= "No puede quedar vacio")
	@Column(name="Nombre", nullable = false, length = 50)
	private String Nombre;
	
	@NotBlank(message= "No puede quedar vacio")
	@Column(name="Descripcion", nullable = false, length = 50)
	private String Descripcion;

	@NotBlank(message= "No puede quedar vacio")
	@Column(name="Unidad", nullable = false, length = 50)
	private String Unidad;

	@Min(value=1,message="Tiene que ser mayor a 0")
	@Column(name="Precio", nullable = false)
	private double Precio;


	private String foto;
	
	public Articulo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Articulo(int idArticulo, String nombre, String descripcion, String unidad, double precio, String foto) {
		super();
		this.idArticulo = idArticulo;
		Nombre = nombre;
		Descripcion = descripcion;
		Unidad = unidad;
		Precio = precio;
		this.foto = foto;
	}

	public int getIdArticulo() {
		return idArticulo;
	}

	public void setIdArticulo(int idArticulo) {
		this.idArticulo = idArticulo;
	}

	public String getNombre() {
		return Nombre;
	}

	public void setNombre(String nombre) {
		Nombre = nombre;
	}

	public String getDescripcion() {
		return Descripcion;
	}

	public void setDescripcion(String descripcion) {
		Descripcion = descripcion;
	}

	public String getUnidad() {
		return Unidad;
	}

	public void setUnidad(String unidad) {
		Unidad = unidad;
	}

	public double getPrecio() {
		return Precio;
	}

	public void setPrecio(double precio) {
		Precio = precio;
	}

	public String getFoto() {
		return foto;
	}

	public void setFoto(String foto) {
		this.foto = foto;
	}
	
	
}
