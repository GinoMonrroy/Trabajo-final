package pe.edu.upc.spring.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Min;

@Entity
@Table(name = "detalle_pedido")
public class Detalle_pedido implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idDetalle_Pedido;

	@ManyToOne
	@JoinColumn(name = "idPedido", nullable = false)
	private Pedido pedido;


	@ManyToOne
	@JoinColumn(name = "idArticulo", nullable = false)
	private Articulo articulo;
	
	@Min(value=1,message="Tiene que ser mayor a 0")
	@Column(name = "Cantidad", nullable = false)
	private int Cantidad;

	public Detalle_pedido() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Detalle_pedido(int idDetalle_Pedido, Pedido pedido, Articulo articulo, int cantidad) {
		super();
		this.idDetalle_Pedido = idDetalle_Pedido;
		this.pedido = pedido;
		this.articulo = articulo;
		Cantidad = cantidad;
	}

	public int getIdDetalle_Pedido() {
		return idDetalle_Pedido;
	}

	public void setIdDetalle_Pedido(int idDetalle_Pedido) {
		this.idDetalle_Pedido = idDetalle_Pedido;
	}

	public Pedido getPedido() {
		return pedido;
	}

	public void setPedido(Pedido pedido) {
		this.pedido = pedido;
	}

	public Articulo getArticulo() {
		return articulo;
	}

	public void setArticulo(Articulo articulo) {
		this.articulo = articulo;
	}

	public int getCantidad() {
		return Cantidad;
	}

	public void setCantidad(int cantidad) {
		Cantidad = cantidad;
	}
	
	
}
