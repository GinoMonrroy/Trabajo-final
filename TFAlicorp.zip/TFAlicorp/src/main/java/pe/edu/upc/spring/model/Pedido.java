package pe.edu.upc.spring.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "pedido")
public class Pedido implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idPedido;
	
    @ManyToOne
	@JoinColumn(name="idAdministrativo", nullable = true, referencedColumnName = "id")
	private Usuario usuario;

	@ManyToOne
	@JoinColumn(name="idCliente", nullable = false, referencedColumnName="idCliente")
	private Cliente cliente;

	@Column(name="Forma_Pago", nullable = false)
	private int Forma_Pago;	
	
	@Column(name="Condicional_Pago", nullable = false)
	private int Condicional_Pago;	
	
	@NotNull
	@Temporal(TemporalType.DATE)
	@Column(name = "FechaGenerada")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date FechaGenerada;
		
	@Column(name="Estado", nullable = false)
	private int Estado;

	public Pedido() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Pedido(int idPedido, Usuario usuario, Cliente cliente, int forma_Pago, int condicional_Pago,
			Date fechaGenerada, int estado) {
		super();
		this.idPedido = idPedido;
		this.usuario = usuario;
		this.cliente = cliente;
		Forma_Pago = forma_Pago;
		Condicional_Pago = condicional_Pago;
		FechaGenerada = fechaGenerada;
		Estado = estado;
	}

	public int getIdPedido() {
		return idPedido;
	}

	public void setIdPedido(int idPedido) {
		this.idPedido = idPedido;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public int getForma_Pago() {
		return Forma_Pago;
	}

	public void setForma_Pago(int forma_Pago) {
		Forma_Pago = forma_Pago;
	}

	public int getCondicional_Pago() {
		return Condicional_Pago;
	}

	public void setCondicional_Pago(int condicional_Pago) {
		Condicional_Pago = condicional_Pago;
	}

	public Date getFechaGenerada() {
		return FechaGenerada;
	}

	public void setFechaGenerada(Date fechaGenerada) {
		FechaGenerada = fechaGenerada;
	}

	public int getEstado() {
		return Estado;
	}

	public void setEstado(int estado) {
		Estado = estado;
	}


	
}
