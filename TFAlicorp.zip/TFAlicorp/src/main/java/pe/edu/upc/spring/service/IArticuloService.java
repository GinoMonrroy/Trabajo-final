package pe.edu.upc.spring.service;

import java.util.List;

import pe.edu.upc.spring.model.Articulo;

public interface IArticuloService {

	public boolean insertar(Articulo articulo);

	public boolean modificar(Articulo articulo);

	public void eliminar(int idArticulo);

	public Articulo listarId(int idArticulo);

	List<Articulo> listar();

	List<Articulo> buscarNombre(String Nombre);

}
