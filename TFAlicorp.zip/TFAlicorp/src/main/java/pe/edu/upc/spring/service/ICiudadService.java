package pe.edu.upc.spring.service;

import java.util.List;

import pe.edu.upc.spring.model.Ciudad;

public interface ICiudadService {


	public boolean insertar(Ciudad ciudad);

	public boolean modificar(Ciudad ciudad);

	public void eliminar(int idCiudad);

	public Ciudad listarId(int idCiudad);

	List<Ciudad> listar();

}
