package pe.edu.upc.spring.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import pe.edu.upc.spring.dao.IPaisDAO;
import pe.edu.upc.spring.model.Pais;
import pe.edu.upc.spring.service.IPaisService;

@Service
public class PaisServiceImpl implements IPaisService {

	@Autowired
	private IPaisDAO dPais;

	@Override
	@Transactional
	public boolean insertar(Pais pais) {
		Pais objPais = dPais.save(pais);
		if (objPais == null) {
			return false;
		} else {
			return true;
		}
	}

	@Override
	@Transactional
	public boolean modificar(Pais pais) {
		boolean flag = false;
		try {
			dPais.save(pais);
			flag = true;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return flag;
	}

	@Override
	@Transactional
	public void eliminar(int idPais) {

		dPais.delete(idPais);

	}

	
	@Override
	@Transactional(readOnly=true)
	public Pais listarId(int idPais) {
		return dPais.findOne(idPais);
	}


	@Override
	@Transactional(readOnly=true)
	public List<Pais> listar() {
		return dPais.findAll();
	}

}
