package pe.upc.business;

import java.io.Serializable;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;
import javax.transaction.Transactional;

import pe.upc.model.entity.SolicitudVehiculo;
import pe.upc.model.repository.SolicitudVehiculoRepository;

@Named
public class SolicitudVehiculoBusiness implements Serializable{
private static final long serialVersionUID = 1L;
	
	@Inject
	private SolicitudVehiculoRepository solicitudrenovacionRepository;
	@Transactional
	public Long insert(SolicitudVehiculo solicitud) throws Exception {
		return solicitudrenovacionRepository.insert(solicitud);
	}

	
	@Transactional
	public Long update(SolicitudVehiculo solicitud) throws Exception{
		return solicitudrenovacionRepository.update(solicitud);
	}
	
	
	public List<SolicitudVehiculo> getAll() throws Exception {
		return solicitudrenovacionRepository.findAll();
	}
	
	
	public List<SolicitudVehiculo> getSolicitudsByName(String name) throws Exception{
		return solicitudrenovacionRepository.findByName(name);
	}

}
