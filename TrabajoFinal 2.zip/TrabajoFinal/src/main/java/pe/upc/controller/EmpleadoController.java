package pe.upc.controller;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.event.SelectEvent;

import pe.upc.business.EmpleadoBusiness;
import pe.upc.model.entity.Empleado;
import pe.upc.util.Message;

@Named
@SessionScoped
public class EmpleadoController implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Inject
	private EmpleadoBusiness empleadoBusiness;
	

	private Empleado empleado;
	private List<Empleado> empleados;
	private Empleado empleadoSelect;
	private String filterName;
	private List<Empleado> empleadosT;
	private List<Empleado> empleadosV;
	
	@PostConstruct
	public void init() {
		empleado = new Empleado();
		empleados = new ArrayList<>();
		empleadosT = new ArrayList<>();
		empleadosV = new ArrayList<>();
		getAllEmpleados();
		getAllEmpleadosT();
		getAllEmpleadosV();
	}
	public void getAllEmpleadosT() {
		try {
			
			List<Empleado> aux = new ArrayList<Empleado>();
			for(Empleado pe : empleados)
			{
				if(pe.getTipo().equalsIgnoreCase("Tecnico"))
				{
					aux.add(pe);
				}
			}
			
			empleadosT = aux;
			
		} catch (Exception e) {
			Message.messageError("Error Carga de Empleados :" + e.getMessage());
		}
	}
	public void getAllEmpleadosV() {
		try {
			
			List<Empleado> aux = new ArrayList<Empleado>();
			for(Empleado pe : empleados)
			{
				if(pe.getTipo().equalsIgnoreCase("Ventas"))
				{
					aux.add(pe);
				}
			}
			
			empleadosV = aux;
			
		} catch (Exception e) {
			Message.messageError("Error Carga de Empleados :" + e.getMessage());
		}
	}
	public void getAllEmpleados() {
		try {
			empleados = empleadoBusiness.getAll();
		} catch (Exception e) {
			Message.messageError("Error Carga de Empleados :" + e.getMessage());
		}
	}
	public String listEmpleado() {
		return "listEmpleado.xhtml";
	}
	public String saveEmpleado() {
		String view = "";
		try {

			if (empleado.getEmpleado_id() != null) {
				empleadoBusiness.update(empleado);
				Message.messageInfo("Registro actualizado exitosamente");
			} else {
				empleadoBusiness.insert(empleado);
				Message.messageInfo("Registro guardado exitosamente");

			}
			this.getAllEmpleados();
			resetForm();
			view = "listEmpleado";
		} catch (Exception e) {
			Message.messageError("Error Empleado :" + e.getStackTrace());
		}

		return view;
	}
	public String newEmpleado() {

		return "insertEmpleado.xhtml";
	}
	
	public String editEmpleado() {
		String view = "";
		try {
			if (this.empleadoSelect != null) {
				this.empleado = empleadoSelect;

				view = "/empleado/updateEmpleado";
			} else {
				Message.messageInfo("Debe seleccionar un empleado");
			}
		} catch (Exception e) {
			Message.messageError("Error Empleado :" + e.getMessage());
		}

		return view;
	}
	public void searchEmpleadoByName() {
		try {

			empleados = empleadoBusiness.getEmpleadosByName(this.filterName.trim());
			resetForm();
			if (empleados.isEmpty()) {
				Message.messageInfo("No se encontraron empleados");

			}

		} catch (Exception e) {
			Message.messageError("Error Empleado Search :" + e.getMessage());
		}
	}
	public void selectEmpleado(SelectEvent e) {
		this.empleadoSelect = (Empleado) e.getObject();
	}

	public void resetForm() {
		this.filterName = "";
		this.empleado = new Empleado();
	}
	public EmpleadoBusiness getEmpleadoBusiness() {
		return empleadoBusiness;
	}
	public void setEmpleadoBusiness(EmpleadoBusiness empleadoBusiness) {
		this.empleadoBusiness = empleadoBusiness;
	}
	public Empleado getEmpleado() {
		return empleado;
	}
	public void setEmpleado(Empleado empleado) {
		this.empleado = empleado;
	}
	public List<Empleado> getEmpleados() {
		return empleados;
	}
	public void setEmpleados(List<Empleado> empleados) {
		this.empleados = empleados;
	}
	public Empleado getEmpleadoSelect() {
		return empleadoSelect;
	}
	public void setEmpleadoSelect(Empleado empleadoSelect) {
		this.empleadoSelect = empleadoSelect;
	}
	public String getFilterName() {
		return filterName;
	}
	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public List<Empleado> getEmpleadosT() {
		return empleadosT;
	}
	public void setEmpleadosT(List<Empleado> empleadosT) {
		this.empleadosT = empleadosT;
	}
	public List<Empleado> getEmpleadosV() {
		return empleadosV;
	}
	public void setEmpleadosV(List<Empleado> empleadosV) {
		this.empleadosV = empleadosV;
	}
	
}
