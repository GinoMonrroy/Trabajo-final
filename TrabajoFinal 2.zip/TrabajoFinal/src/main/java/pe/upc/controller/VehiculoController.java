package pe.upc.controller;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.event.SelectEvent;


import pe.upc.business.UsuarioBusiness;
import pe.upc.business.VehiculoBusiness;
import pe.upc.model.entity.Usuario;
import pe.upc.model.entity.Vehiculo;
import pe.upc.util.Message;

@Named
@SessionScoped
public class VehiculoController implements Serializable{
	private static final long serialVersionUID = 1L;

	@Inject
	private VehiculoBusiness vehiculoBusiness;

	@Inject
	private UsuarioBusiness usuarioBusiness;

	private Vehiculo vehiculo;
	private List<Vehiculo> vehiculos;
	private List<Vehiculo> vehiculosnuevos;
	private List<Vehiculo> vehiculosviejos;
	private Vehiculo vehiculoSelect;

	private List<Vehiculo> listvxc;
	
	public List<Vehiculo> getListvxc() {
		return listvxc;
	}

	public void setListvxc(List<Vehiculo> listvxc) {
		this.listvxc = listvxc;
	}

	private Usuario usuario;
	private List<Usuario> usuarios;

	private String filterName;
	
	@PostConstruct
	public void init() {
		vehiculo = new Vehiculo();
		vehiculos = new ArrayList<Vehiculo>();
		vehiculosnuevos = new ArrayList<Vehiculo>();
		vehiculosviejos = new ArrayList<Vehiculo>();

		usuario = new Usuario();
		usuarios = new ArrayList<>();

		getAllVehiculos();
		getAllVehiculosN();
		getAllVehiculosV();
	}
	
	public void getAllVehiculos() {
		try {
			vehiculos = vehiculoBusiness.getAll();
		} catch (Exception e) {
			Message.messageError("Error Carga de Vehiculos :" + e.getMessage());
		}
	}
	public void getAllVehiculosN() {
		try {
			
			List<Vehiculo> aux = new ArrayList<Vehiculo>();
			for(Vehiculo pe : vehiculos)
			{
				if(pe.getTipo().equalsIgnoreCase("Nuevo"))
				{
					aux.add(pe);
				}
			}
			
			vehiculosnuevos = aux;
			
		} catch (Exception e) {
			Message.messageError("Error Carga de Vehiculos :" + e.getMessage());
		}
	}
	
	public void getAllVehiculosV() {
		try {
			
			List<Vehiculo> aux = new ArrayList<Vehiculo>();
			for(Vehiculo pe : vehiculos)
			{
				if(pe.getTipo().equalsIgnoreCase("Usado"))
				{
					aux.add(pe);
				}
			}
			
			vehiculosviejos = aux;
			
		} catch (Exception e) {
			Message.messageError("Error Carga de Vehiculos :" + e.getMessage());
		}
	}
	public void listarVehiculoxUsuario(Usuario c) {

		try {
			Vehiculo p = new Vehiculo();
			p.setUsuario(c);
			List<Vehiculo> aux = new ArrayList<Vehiculo>();
			for(Vehiculo pe : vehiculos)
			{
				if(pe.getUsuario().getUsuario_id() == p.getUsuario().getUsuario_id())
				{
					aux.add(pe);
				}
			}

			
			listvxc = aux; 
		
		} catch (Exception e) {
			e.getMessage();
		}
}
	public String newVehiculo() {

		try {
			this.usuarios = usuarioBusiness.getAll();

			resetForm();
		} catch (Exception e) {
			// TODO: handle exception
		}

		return "insert.xhtml";
	}
	
	public String listVehiculo() {
		return "list.xhtml";
	}
	
	public String saveVehiculo() {
		String view = "";
		try {

			if (vehiculo.getVehiculo_id() != null) {
				vehiculoBusiness.update(vehiculo);
				Message.messageInfo("Registro actualizado exitosamente");
			} else {
				vehiculo.setUsuario(usuario);
				vehiculoBusiness.insert(vehiculo);
				Message.messageInfo("Registro guardado exitosamente");

			}
			this.getAllVehiculos();
			resetForm();
			view = "list";
		} catch (Exception e) {
			Message.messageError("Error Vehiculo :" + e.getStackTrace());
		}

		return view;
	}
	
	public String editVehiculo() {
		String view = "";
		try {
			if (this.vehiculoSelect != null) {
				this.vehiculo = vehiculoSelect;

				view = "/vehiculo/update";
			} else {
				Message.messageInfo("Debe seleccionar un vehiculo");
			}
		} catch (Exception e) {
			Message.messageError("Error Vehiculo :" + e.getMessage());
		}

		return view;
	}
	
	public void searchVehiculosByName() {
		try {

			vehiculos = vehiculoBusiness.getVehiculosByName(this.filterName.trim());
			resetForm();
			if (vehiculos.isEmpty()) {
				Message.messageInfo("No se encontraron vehiculos");

			}

		} 
		catch (Exception e) {
			Message.messageError("Error Vehiculo Search :" + e.getMessage());
		}
	}
	
	public void selectVehiculo(SelectEvent e) {
		this.vehiculoSelect = (Vehiculo) e.getObject();
	}

	public void resetForm() {
		this.filterName = "";
		this.vehiculo = new Vehiculo();
	}
	
	
	public List<Vehiculo> getVehiculosviejos() {
		return vehiculosviejos;
	}

	public void setVehiculosviejos(List<Vehiculo> vehiculosviejos) {
		this.vehiculosviejos = vehiculosviejos;
	}

	public VehiculoBusiness getVehiculoBusiness() {
		return vehiculoBusiness;
	}

	public void setVehiculoBusiness(VehiculoBusiness vehiculoBusiness) {
		this.vehiculoBusiness = vehiculoBusiness;
	}

	public UsuarioBusiness getUsuarioBusiness() {
		return usuarioBusiness;
	}

	public void setUsuarioBusiness(UsuarioBusiness usuarioBusiness) {
		this.usuarioBusiness = usuarioBusiness;
	}

	public Vehiculo getVehiculo() {
		return vehiculo;
	}

	public void setVehiculo(Vehiculo vehiculo) {
		this.vehiculo = vehiculo;
	}

	public List<Vehiculo> getVehiculos() {
		return vehiculos;
	}

	public void setVehiculos(List<Vehiculo> vehiculos) {
		this.vehiculos = vehiculos;
	}

	public Vehiculo getVehiculoSelect() {
		return vehiculoSelect;
	}

	public void setVehiculoSelect(Vehiculo vehiculoSelect) {
		this.vehiculoSelect = vehiculoSelect;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public List<Usuario> getUsuarios() {
		return usuarios;
	}

	public void setUsuarios(List<Usuario> usuarios) {
		this.usuarios = usuarios;
	}

	public String getFilterName() {
		return filterName;
	}

	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}

	
	public List<Vehiculo> getVehiculosnuevos() {
		return vehiculosnuevos;
	}

	public void setVehiculosnuevos(List<Vehiculo> vehiculosnuevos) {
		this.vehiculosnuevos = vehiculosnuevos;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
