package pe.upc.model.entity;

public class DetalleFalla {

}
