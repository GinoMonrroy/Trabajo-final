package pe.upc.model.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "solicitudrenovacions")
public class SolicitudRenovacion {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idsolicitud;
	
	@ManyToOne
	@JoinColumn(name = "usuario_id")
	private Usuario usuario;
	
	private double precioEstimado;
	private double precioFinal;
	private String estado;
	
	public Long getIdsolicitud() {
		return idsolicitud;
	}
	public void setIdsolicitud(Long idsolicitud) {
		this.idsolicitud = idsolicitud;
	}
	public Usuario getUsuario() {
		return usuario;
	}
	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
	public double getPrecioEstimado() {
		return precioEstimado;
	}
	public void setPrecioEstimado(double precioEstimado) {
		this.precioEstimado = precioEstimado;
	}
	public double getPrecioFinal() {
		return precioFinal;
	}
	public void setPrecioFinal(double precioFinal) {
		this.precioFinal = precioFinal;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	

	
}
