package pe.upc.model.repository;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import pe.upc.model.entity.SolicitudRenovacion;

@Named
public class SolicitudRenovacionRepository implements Serializable{
	private static final long serialVersionUID = 1L;

	@PersistenceContext(unitName = "pwPU")
	private EntityManager em;
	
	public Long insert(SolicitudRenovacion solicitud) throws Exception {
		em.persist(solicitud);
		return solicitud.getIdsolicitud();
	}
	
	public Long update(SolicitudRenovacion solicitud) throws Exception {
		em.merge(solicitud);
		return solicitud.getIdsolicitud();
	}
	public List<SolicitudRenovacion> findAll() throws Exception {
		List<SolicitudRenovacion> solicituds = new ArrayList<>();

		TypedQuery<SolicitudRenovacion> query = em.createQuery("FROM SolicitudRenovacion p", SolicitudRenovacion.class);
		solicituds = query.getResultList();

		return solicituds;
	}
	public List<SolicitudRenovacion> findByName(String name) throws Exception {
		List<SolicitudRenovacion> solicitud = new ArrayList<>();

		TypedQuery<SolicitudRenovacion> query = em.createQuery("FROM SolicitudRenovacion p WHERE p.usuario_id.nombre LIKE ?1", SolicitudRenovacion.class);
		query.setParameter(1, "%" + name + "%");
		solicitud = query.getResultList();

		return solicitud;
	}
}
