package pe.upc.business;

import java.io.Serializable;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;
import javax.transaction.Transactional;

import pe.upc.model.entity.SolicitudRenovacion;
import pe.upc.model.repository.SolicitudRenovacionRepository;

@Named
public class SolicitudRenovacionBusiness implements Serializable{
private static final long serialVersionUID = 1L;
	
	@Inject
	private SolicitudRenovacionRepository solicitudrenovacionRepository;
	@Transactional
	public Long insert(SolicitudRenovacion solicitud) throws Exception {
		return solicitudrenovacionRepository.insert(solicitud);
	}

	
	@Transactional
	public Long update(SolicitudRenovacion solicitud) throws Exception{
		return solicitudrenovacionRepository.update(solicitud);
	}
	
	
	public List<SolicitudRenovacion> getAll() throws Exception {
		return solicitudrenovacionRepository.findAll();
	}
	
	
	public List<SolicitudRenovacion> getSolicitudsByName(String name) throws Exception{
		return solicitudrenovacionRepository.findByName(name);
	}

}
