package pe.upc.model.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "fallas")
public class Falla {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long falla_id;
	private String nombre;
	public Long getFalla_id() {
		return falla_id;
	}
	public void setFalla_id(Long falla_id) {
		this.falla_id = falla_id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
		
}
