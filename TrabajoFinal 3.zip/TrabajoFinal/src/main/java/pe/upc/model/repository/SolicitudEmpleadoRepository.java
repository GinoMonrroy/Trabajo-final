package pe.upc.model.repository;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import pe.upc.model.entity.SolicitudEmpleado;

@Named
public class SolicitudEmpleadoRepository implements Serializable{
	private static final long serialVersionUID = 1L;

	@PersistenceContext(unitName = "pwPU")
	private EntityManager em;
	
	public Long insert(SolicitudEmpleado solicitud) throws Exception {
		em.persist(solicitud);
		return solicitud.getId();
	}
	
	public Long update(SolicitudEmpleado solicitud) throws Exception {
		em.merge(solicitud);
		return solicitud.getId();
	}
	public List<SolicitudEmpleado> findAll() throws Exception {
		List<SolicitudEmpleado> solicituds = new ArrayList<>();

		TypedQuery<SolicitudEmpleado> query = em.createQuery("FROM SolicitudEmpleado p", SolicitudEmpleado.class);
		solicituds = query.getResultList();

		return solicituds;
	}
	public List<SolicitudEmpleado> findByName(String name) throws Exception {
		List<SolicitudEmpleado> solicitud = new ArrayList<>();

		TypedQuery<SolicitudEmpleado> query = em.createQuery("FROM SolicitudEmpleado p WHERE p.id LIKE ?1", SolicitudEmpleado.class);
		query.setParameter(1, "%" + name + "%");
		solicitud = query.getResultList();

		return solicitud;
	}
}
