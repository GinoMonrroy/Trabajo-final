INSERT INTO usuarios (nombre,apellido,correo,licencia,password,telefono) VALUES('Empresa','','',0,'',0);
INSERT INTO usuarios (nombre,apellido,correo,licencia,password,telefono) VALUES('Hugo','Olivera','Hugo@gmail.com',0123456789,'Holamundo',999999999);
INSERT INTO usuarios (nombre,apellido,correo,licencia,password,telefono) VALUES('Alonzo','Martinez','Alonzo@gmail.com',8795412630,'Holamundo',888888888);
INSERT INTO usuarios (nombre,apellido,correo,licencia,password,telefono) VALUES('Gino','Monrroy','ginomonrroy@gmail.com',1234567890,'Holamundo',968689605);

INSERT INTO vehiculos (modelo,annio,tipo,usuario_id,precio) VALUES('Yaris',2015,'Nuevo',1,15000);
INSERT INTO vehiculos (modelo,annio,tipo,usuario_id,precio) VALUES('Yaris',2017,'Usado',4,8000);
INSERT INTO vehiculos (modelo,annio,tipo,usuario_id,precio) VALUES('Yaris',2019,'Usado',2,12000);

INSERT INTO empleados (nombre,telefono,dni,tipo,password) VALUES ('Alfredo',987654321,'76278846','Tecnico','admin');
INSERT INTO empleados (nombre,telefono,dni,tipo,password) VALUES ('Javier',574682319,'68792143','Ventas','admin');
INSERT INTO empleados (nombre,telefono,dni,tipo,password) VALUES ('Alison',897453612,'25737700','Ventas','admin');
INSERT INTO empleados (nombre,telefono,dni,tipo,password) VALUES ('Luis',925482365,'87652147','Tecnico','admin');