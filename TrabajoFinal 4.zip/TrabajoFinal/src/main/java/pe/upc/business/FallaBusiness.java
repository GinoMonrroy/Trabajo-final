package pe.upc.business;

import java.io.Serializable;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;
import javax.transaction.Transactional;

import pe.upc.model.entity.Falla;
import pe.upc.model.repository.FallaRepository;

@Named
public class FallaBusiness implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Inject
	private FallaRepository fallaRepository;

	
	public List<Falla> getAll() throws Exception {
		return fallaRepository.findAll();
	}
	@Transactional
	public Long insert(Falla falla) throws Exception {
		return fallaRepository.insert(falla);
	}
	
	public Long update(Falla falla) throws Exception{
		return fallaRepository.update(falla);
	}
	public List<Falla> getFallasByName(String name) throws Exception{
		return fallaRepository.findByName(name);
	}
}
