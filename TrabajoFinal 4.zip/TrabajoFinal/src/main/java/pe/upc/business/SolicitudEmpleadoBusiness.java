package pe.upc.business;

import java.io.Serializable;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;
import javax.transaction.Transactional;

import pe.upc.model.entity.SolicitudEmpleado;
import pe.upc.model.repository.SolicitudEmpleadoRepository;

@Named
public class SolicitudEmpleadoBusiness implements Serializable{
private static final long serialVersionUID = 1L;
	
	@Inject
	private SolicitudEmpleadoRepository solicitudEmpleadorenovacionRepository;
	@Transactional
	public Long insert(SolicitudEmpleado solicitudEmpleado) throws Exception {
		return solicitudEmpleadorenovacionRepository.insert(solicitudEmpleado);
	}

	
	@Transactional
	public Long update(SolicitudEmpleado solicitudEmpleado) throws Exception{
		return solicitudEmpleadorenovacionRepository.update(solicitudEmpleado);
	}
	
	
	public List<SolicitudEmpleado> getAll() throws Exception {
		return solicitudEmpleadorenovacionRepository.findAll();
	}
	
	
	public List<SolicitudEmpleado> getSolicitudsByName(String name) throws Exception{
		return solicitudEmpleadorenovacionRepository.findByName(name);
	}

}
