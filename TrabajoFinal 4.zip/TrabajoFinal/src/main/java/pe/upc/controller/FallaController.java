package pe.upc.controller;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.event.SelectEvent;

import pe.upc.business.FallaBusiness;
import pe.upc.model.entity.Falla;
import pe.upc.util.Message;

@Named
@SessionScoped
public class FallaController implements Serializable{
private static final long serialVersionUID = 1L;
	

	@Inject
	private FallaBusiness fallaBusiness;
	

	private Falla falla;
	private List<Falla> fallas;
	private Falla fallaSelect;
	private String filterName;
	@PostConstruct
	public void init() {
		falla = new Falla();
		fallas = new ArrayList<>();

		getAllFallas();
	}
	public void getAllFallas() {
		try {
			fallas = fallaBusiness.getAll();
		} catch (Exception e) {
			Message.messageError("Error Carga de fallas :" + e.getMessage());
		}
	}
	public String listFalla() {
		return "listFalla.xhtml";
	}
	public String saveFalla() {
		String view = "";
		try {

			if (falla.getFalla_id() != null) {
				fallaBusiness.update(falla);
				Message.messageInfo("Registro actualizado exitosamente");
			} else {
				fallaBusiness.insert(falla);
				Message.messageInfo("Registro guardado exitosamente");

			}
			this.getAllFallas();
			resetForm();
			view = "listFalla";
		} catch (Exception e) {
			Message.messageError("Error Empleado :" + e.getStackTrace());
		}

		return view;
	}
	public String newFalla() {

		return "insertFalla.xhtml";
	}
	
	public String editFalla() {
		String view = "";
		try {
			if (this.fallaSelect != null) {
				this.falla = fallaSelect;

				view = "/falla/updateFalla";
			} else {
				Message.messageInfo("Debe seleccionar una falla");
			}
		} catch (Exception e) {
			Message.messageError("Error Falla :" + e.getMessage());
		}

		return view;
	}
	public void searchFallaByName() {
		try {

			fallas = fallaBusiness.getFallasByName(this.filterName.trim());
			resetForm();
			if (fallas.isEmpty()) {
				Message.messageInfo("No se encontraron fallas");

			}

		} catch (Exception e) {
			Message.messageError("Error Falla Search :" + e.getMessage());
		}
	}
	public void selectFalla(SelectEvent e) {
		this.fallaSelect = (Falla) e.getObject();
	}

	public void resetForm() {
		this.filterName = "";
		this.falla = new Falla();
	}
	public FallaBusiness getFallaBusiness() {
		return fallaBusiness;
	}
	public void setFallaBusiness(FallaBusiness fallaBusiness) {
		this.fallaBusiness = fallaBusiness;
	}
	public Falla getFalla() {
		return falla;
	}
	public void setFalla(Falla falla) {
		this.falla = falla;
	}
	public List<Falla> getFallas() {
		return fallas;
	}
	public void setFallas(List<Falla> fallas) {
		this.fallas = fallas;
	}
	public Falla getFallaSelect() {
		return fallaSelect;
	}
	public void setFallaSelect(Falla fallaSelect) {
		this.fallaSelect = fallaSelect;
	}
	public String getFilterName() {
		return filterName;
	}
	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
