package pe.upc.controller;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.event.SelectEvent;

import pe.upc.business.EmpleadoBusiness;
import pe.upc.business.SolicitudEmpleadoBusiness;
import pe.upc.business.SolicitudRenovacionBusiness;
import pe.upc.business.SolicitudVehiculoBusiness;
import pe.upc.business.UsuarioBusiness;
import pe.upc.business.VehiculoBusiness;
import pe.upc.model.entity.Empleado;
import pe.upc.model.entity.SolicitudEmpleado;
import pe.upc.model.entity.SolicitudRenovacion;
import pe.upc.model.entity.SolicitudVehiculo;
import pe.upc.model.entity.Usuario;
import pe.upc.model.entity.Vehiculo;
import pe.upc.util.Message;

@Named
@SessionScoped
public class SolicitudController implements Serializable{
	private static final long serialVersionUID = 1L;

	@Inject
	private VehiculoBusiness vehiculoBusiness;

	@Inject
	private SolicitudRenovacionBusiness solicitudrenovacionBusiness;
	
	@Inject
	private SolicitudVehiculoBusiness solicitudvehiculoBusiness;
	
	@Inject
	private SolicitudEmpleadoBusiness solicitudempleadoBusiness;
	
	@Inject
	private EmpleadoBusiness empleadoBusiness;
	
	@Inject
	private UsuarioBusiness usuarioBusiness;
	
	private SolicitudRenovacion solicitud;
	private List<SolicitudRenovacion> solicituds;
	private SolicitudRenovacion solicitudSelect;
	
	private Vehiculo vehiculoN;
	private Vehiculo vehiculoV;
	private Vehiculo vehiculo;
	private List<Vehiculo> vehiculos;
	
	private Usuario usuario;
	private List<Usuario> usuarios;
	
	private Empleado empleadoT;
	private Empleado empleadoV;
	private Empleado empleado;
	private List<Empleado> empleados;
	
	private SolicitudEmpleado solicitudempleado;
	private List<SolicitudEmpleado> solicitudempleados;
	
	private SolicitudVehiculo solicitudvehiculoViejo;
	private SolicitudVehiculo solicitudvehiculoNuevo;
	private List<SolicitudVehiculo> solicitudvehiculos;
	
	private SolicitudEmpleado solicitudempleadoTecnico;
	private SolicitudEmpleado solicitudempleadoVenta;
	
	
	private String filterName;
	
	@PostConstruct
	public void init() {
		
		usuario = new Usuario();
		usuarios = new ArrayList<>();
		
		vehiculo = new Vehiculo();
		vehiculos = new ArrayList<>();

		solicitud = new SolicitudRenovacion();
		solicituds = new ArrayList<SolicitudRenovacion>();
		
		empleado = new Empleado();
		empleados = new ArrayList<>();
		
		solicitudempleado = new SolicitudEmpleado();
		solicitudempleados = new ArrayList<>();
		
		solicitudvehiculoNuevo = new SolicitudVehiculo();
		solicitudvehiculoViejo = new SolicitudVehiculo();
		solicitudvehiculos = new ArrayList<>();
		
		solicitudempleadoVenta = new SolicitudEmpleado();
		solicitudempleadoTecnico = new SolicitudEmpleado();
		getAllSolicituds();
	}
	public void getAllSolicituds() {
		try {
			solicituds = solicitudrenovacionBusiness.getAll();
		} catch (Exception e) {
			Message.messageError("Error Carga de Solicitudes :" + e.getMessage());
		}
	}
	public String newSolicitud() {

		try {
			this.usuarios = usuarioBusiness.getAll();
			this.empleados = empleadoBusiness.getAll();
			this.vehiculos = vehiculoBusiness.getAll();
			this.solicitudempleados = solicitudempleadoBusiness.getAll();
			this.solicitudvehiculos = solicitudvehiculoBusiness.getAll();
			resetForm();
		} catch (Exception e) {
			// TODO: handle exception
		}

		return "insertSolicitud.xhtml";
	}
	public String listSolicituds() {
		return "listSolicitud.xhtml";
	}
	
	public String saveSolicitud() {
		String view = "";
		try {
			if(solicitud.getIdsolicitud()!= null) {
			solicitudempleadoBusiness.update(solicitudempleadoVenta);
			solicitudempleadoBusiness.update(solicitudempleadoTecnico);
			solicitudvehiculoBusiness.update(solicitudvehiculoViejo);
			solicitudvehiculoBusiness.update(solicitudvehiculoNuevo);
			solicitudrenovacionBusiness.update(solicitud);
			Message.messageInfo("Registro actualizado exitosamente");
			}
			else
			{
				solicitud.setUsuario(usuario);
				solicitudempleadoBusiness.insert(solicitudempleadoVenta);
				solicitudempleadoBusiness.insert(solicitudempleadoTecnico);
				solicitudvehiculoBusiness.insert(solicitudvehiculoViejo);
				solicitudvehiculoBusiness.insert(solicitudvehiculoNuevo);
				solicitudrenovacionBusiness.insert(solicitud);
			
			Message.messageInfo("Registro guardado exitosamente");
			}
			this.getAllSolicituds();
			resetForm();
			view = "listSolicitud";
		} catch (Exception e) {
			Message.messageError("Error Solicitud :" + e.getStackTrace());
		}
		return view;
	}
	
	public String editSolicitud() {
		String view = "";
		try {
			if (this.solicitudSelect != null) {
				this.solicitud = solicitudSelect;

				view = "/solicitud/update";
			} else {
				Message.messageInfo("Debe seleccionar una solicitud");
			}
		} catch (Exception e) {
			Message.messageError("Error Solicitud :" + e.getMessage());
		}

		return view;
	}
	public void searchSolicitudsByName() {
		try {

			solicituds = solicitudrenovacionBusiness.getSolicitudsByName(this.filterName.trim());
			resetForm();
			if (solicituds.isEmpty()) {
				Message.messageInfo("No se encontraron solicitudes");

			}

		} 
		catch (Exception e) {
			Message.messageError("Error Solicitud Search :" + e.getMessage());
		}
	}
	public void selectSolicitud(SelectEvent e) {
		this.solicitudSelect = (SolicitudRenovacion) e.getObject();
	}

	public void resetForm() {
		this.filterName = "";
		this.solicitud = new SolicitudRenovacion();
	}
	public VehiculoBusiness getVehiculoBusiness() {
		return vehiculoBusiness;
	}
	public void setVehiculoBusiness(VehiculoBusiness vehiculoBusiness) {
		this.vehiculoBusiness = vehiculoBusiness;
	}
	public SolicitudRenovacionBusiness getSolicitudrenovacionBusiness() {
		return solicitudrenovacionBusiness;
	}
	public void setSolicitudrenovacionBusiness(SolicitudRenovacionBusiness solicitudrenovacionBusiness) {
		this.solicitudrenovacionBusiness = solicitudrenovacionBusiness;
	}
	public SolicitudVehiculoBusiness getSolicitudvehiculoBusiness() {
		return solicitudvehiculoBusiness;
	}
	public void setSolicitudvehiculoBusiness(SolicitudVehiculoBusiness solicitudvehiculoBusiness) {
		this.solicitudvehiculoBusiness = solicitudvehiculoBusiness;
	}
	public SolicitudEmpleadoBusiness getSolicitudempleadoBusiness() {
		return solicitudempleadoBusiness;
	}
	public void setSolicitudempleadoBusiness(SolicitudEmpleadoBusiness solicitudempleadoBusiness) {
		this.solicitudempleadoBusiness = solicitudempleadoBusiness;
	}
	public EmpleadoBusiness getEmpleadoBusiness() {
		return empleadoBusiness;
	}
	public void setEmpleadoBusiness(EmpleadoBusiness empleadoBusiness) {
		this.empleadoBusiness = empleadoBusiness;
	}
	public SolicitudRenovacion getSolicitud() {
		return solicitud;
	}
	public void setSolicitud(SolicitudRenovacion solicitud) {
		this.solicitud = solicitud;
	}
	public List<SolicitudRenovacion> getSolicituds() {
		return solicituds;
	}
	public void setSolicituds(List<SolicitudRenovacion> solicituds) {
		this.solicituds = solicituds;
	}
	public SolicitudRenovacion getSolicitudSelect() {
		return solicitudSelect;
	}
	public void setSolicitudSelect(SolicitudRenovacion solicitudSelect) {
		this.solicitudSelect = solicitudSelect;
	}
	public Vehiculo getVehiculoN() {
		return vehiculoN;
	}
	public void setVehiculoN(Vehiculo vehiculoN) {
		this.vehiculoN = vehiculoN;
	}
	public Vehiculo getVehiculoV() {
		return vehiculoV;
	}
	public void setVehiculoV(Vehiculo vehiculoV) {
		this.vehiculoV = vehiculoV;
	}
	public Vehiculo getVehiculo() {
		return vehiculo;
	}
	public void setVehiculo(Vehiculo vehiculo) {
		this.vehiculo = vehiculo;
	}
	public List<Vehiculo> getVehiculos() {
		return vehiculos;
	}
	public void setVehiculos(List<Vehiculo> vehiculos) {
		this.vehiculos = vehiculos;
	}
	public Empleado getEmpleadoT() {
		return empleadoT;
	}
	public void setEmpleadoT(Empleado empleadoT) {
		this.empleadoT = empleadoT;
	}
	public Empleado getEmpleadoV() {
		return empleadoV;
	}
	public void setEmpleadoV(Empleado empleadoV) {
		this.empleadoV = empleadoV;
	}
	public Empleado getEmpleado() {
		return empleado;
	}
	public void setEmpleado(Empleado empleado) {
		this.empleado = empleado;
	}
	public List<Empleado> getEmpleados() {
		return empleados;
	}
	public void setEmpleados(List<Empleado> empleados) {
		this.empleados = empleados;
	}
	public SolicitudEmpleado getSolicitudempleado() {
		return solicitudempleado;
	}
	public void setSolicitudempleado(SolicitudEmpleado solicitudempleado) {
		this.solicitudempleado = solicitudempleado;
	}
	public List<SolicitudEmpleado> getSolicitudempleados() {
		return solicitudempleados;
	}
	public void setSolicitudempleados(List<SolicitudEmpleado> solicitudempleados) {
		this.solicitudempleados = solicitudempleados;
	}
	public SolicitudVehiculo getSolicitudvehiculoViejo() {
		return solicitudvehiculoViejo;
	}
	public void setSolicitudvehiculoViejo(SolicitudVehiculo solicitudvehiculoViejo) {
		this.solicitudvehiculoViejo = solicitudvehiculoViejo;
	}
	public SolicitudVehiculo getSolicitudvehiculoNuevo() {
		return solicitudvehiculoNuevo;
	}
	public void setSolicitudvehiculoNuevo(SolicitudVehiculo solicitudvehiculoNuevo) {
		this.solicitudvehiculoNuevo = solicitudvehiculoNuevo;
	}
	public List<SolicitudVehiculo> getSolicitudvehiculos() {
		return solicitudvehiculos;
	}
	public void setSolicitudvehiculos(List<SolicitudVehiculo> solicitudvehiculos) {
		this.solicitudvehiculos = solicitudvehiculos;
	}
	public SolicitudEmpleado getSolicitudempleadoTecnico() {
		return solicitudempleadoTecnico;
	}
	public void setSolicitudempleadoTecnico(SolicitudEmpleado solicitudempleadoTecnico) {
		this.solicitudempleadoTecnico = solicitudempleadoTecnico;
	}
	public SolicitudEmpleado getSolicitudempleadoVenta() {
		return solicitudempleadoVenta;
	}
	public void setSolicitudempleadoVenta(SolicitudEmpleado solicitudempleadoVenta) {
		this.solicitudempleadoVenta = solicitudempleadoVenta;
	}
	public String getFilterName() {
		return filterName;
	}
	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Usuario getUsuario() {
		return usuario;
	}
	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
	public List<Usuario> getUsuarios() {
		return usuarios;
	}
	public void setUsuarios(List<Usuario> usuarios) {
		this.usuarios = usuarios;
	}
	
}
