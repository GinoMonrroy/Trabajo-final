package pe.upc.controller;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.event.SelectEvent;

import pe.upc.business.EmpleadoBusiness;
import pe.upc.business.SolicitudEmpleadoBusiness;
import pe.upc.business.SolicitudRenovacionBusiness;
import pe.upc.model.entity.Empleado;
import pe.upc.model.entity.SolicitudEmpleado;
import pe.upc.model.entity.SolicitudRenovacion;
import pe.upc.util.Message;

@Named
@SessionScoped
public class SolicitudEController implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Inject
	private EmpleadoBusiness empleadoBusiness;

	@Inject
	private SolicitudEmpleadoBusiness solicitudEBusiness;
	
	@Inject
	private SolicitudRenovacionBusiness solicitudRBusiness;
	
	private Empleado empleado;
	private List<Empleado> empleados;
	
	private SolicitudRenovacion solicitud;
	private List<SolicitudRenovacion> solicituds;
	
	private SolicitudEmpleado solicitudE;
	private List<SolicitudEmpleado> solicitudsV;
	private SolicitudEmpleado solicitudEselect;
	
	private String filterName;
	
	@PostConstruct
	public void init() {
		empleado = new Empleado();
		empleados = new ArrayList<Empleado>();

		solicitud = new SolicitudRenovacion();
		solicituds = new ArrayList<>();
		
		solicitudE = new SolicitudEmpleado();
		solicitudsV = new ArrayList<>();

		getAllSolicitudsV();
	}
	public void getAllSolicitudsV() {
		try {
			solicitudsV = solicitudEBusiness.getAll();
		} catch (Exception e) {
			Message.messageError("Error Carga de Productos :" + e.getMessage());
		}
	}
	public String newSolicitudV() {

		try {
			this.empleados = empleadoBusiness.getAll();
			this.solicituds = solicitudRBusiness.getAll();
			resetForm();
		} catch (Exception e) {
			// TODO: handle exception
		}

		return "insertSolicitud.xhtml";
	}
	public String listProduct() {
		return "listSolicitud.xhtml";
	}
	public String saveSolicitudV() {
		String view = "";
		try {

			if (solicitudE.getId() != null) {
				solicitudE.setSolicitud(solicitud);
				solicitudE.setEmpleado(empleado);
				solicitudEBusiness.update(solicitudE);
				Message.messageInfo("Registro actualizado exitosamente");
			} else {
				solicitudE.setSolicitud(solicitud);
				solicitudE.setEmpleado(empleado);
				solicitudEBusiness.insert(solicitudE);
				Message.messageInfo("Registro guardado exitosamente");

			}
			this.getAllSolicitudsV();
			resetForm();
			view = "list";
		} catch (Exception e) {
			Message.messageError("Error solicitud :" + e.getStackTrace());
		}

		return view;
	}
	public String editProduct() {
		String view = "";
		try {
			if (this.solicitudEselect != null) {
				this.solicitudE = solicitudEselect;

				view = "/solicitud/update";
			} else {
				Message.messageInfo("Debe seleccionar un producto");
			}
		} catch (Exception e) {
			Message.messageError("Error Product :" + e.getMessage());
		}

		return view;
	}
	public void searchProductByName() {
		try {

			solicitudsV = solicitudEBusiness.getSolicitudsByName(this.filterName.trim());
			resetForm();
			if (solicitudsV.isEmpty()) {
				Message.messageInfo("No se encontraron productos");

			}

		} catch (Exception e) {
			Message.messageError("Error Product Search :" + e.getMessage());
		}
	}
	public void selectSolicitudV(SelectEvent e) {
		this.solicitudEselect = (SolicitudEmpleado) e.getObject();
	}

	public void resetForm() {
		this.filterName = "";
		this.solicitudE = new SolicitudEmpleado();
	}
	public EmpleadoBusiness getEmpleadoBusiness() {
		return empleadoBusiness;
	}
	public void setEmpleadoBusiness(EmpleadoBusiness empleadoBusiness) {
		this.empleadoBusiness = empleadoBusiness;
	}
	public SolicitudEmpleadoBusiness getSolicitudVBusiness() {
		return solicitudEBusiness;
	}
	public void setSolicitudVBusiness(SolicitudEmpleadoBusiness solicitudEBusiness) {
		this.solicitudEBusiness = solicitudEBusiness;
	}
	public SolicitudRenovacionBusiness getSolicitudRBusiness() {
		return solicitudRBusiness;
	}
	public void setSolicitudRBusiness(SolicitudRenovacionBusiness solicitudRBusiness) {
		this.solicitudRBusiness = solicitudRBusiness;
	}
	public Empleado getEmpleado() {
		return empleado;
	}
	public void setEmpleado(Empleado empleado) {
		this.empleado = empleado;
	}
	public List<Empleado> getEmpleados() {
		return empleados;
	}
	public void setEmpleados(List<Empleado> empleados) {
		this.empleados = empleados;
	}
	public SolicitudRenovacion getSolicitud() {
		return solicitud;
	}
	public void setSolicitud(SolicitudRenovacion solicitud) {
		this.solicitud = solicitud;
	}
	public List<SolicitudRenovacion> getSolicituds() {
		return solicituds;
	}
	public void setSolicituds(List<SolicitudRenovacion> solicituds) {
		this.solicituds = solicituds;
	}
	public SolicitudEmpleado getSolicitudV() {
		return solicitudE;
	}
	public void setSolicitudV(SolicitudEmpleado solicitudE) {
		this.solicitudE = solicitudE;
	}
	public List<SolicitudEmpleado> getSolicitudsV() {
		return solicitudsV;
	}
	public void setSolicitudsV(List<SolicitudEmpleado> solicitudsV) {
		this.solicitudsV = solicitudsV;
	}
	public SolicitudEmpleado getSolicitudVselect() {
		return solicitudEselect;
	}
	public void setSolicitudVselect(SolicitudEmpleado solicitudEselect) {
		this.solicitudEselect = solicitudEselect;
	}
	public String getFilterName() {
		return filterName;
	}
	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
