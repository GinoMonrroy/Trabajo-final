package pe.upc.controller;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.primefaces.event.SelectEvent;

import pe.upc.business.VehiculoBusiness;
import pe.upc.business.SolicitudVehiculoBusiness;
import pe.upc.business.SolicitudRenovacionBusiness;
import pe.upc.model.entity.Vehiculo;
import pe.upc.model.entity.SolicitudVehiculo;
import pe.upc.model.entity.SolicitudRenovacion;
import pe.upc.util.Message;

@Named
@SessionScoped
public class SolicitudVController implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Inject
	private VehiculoBusiness vehiculoBusiness;

	@Inject
	private SolicitudVehiculoBusiness solicitudVBusiness;
	
	@Inject
	private SolicitudRenovacionBusiness solicitudRBusiness;
	
	private Vehiculo vehiculo;
	private List<Vehiculo> vehiculos;
	
	private SolicitudRenovacion solicitud;
	private List<SolicitudRenovacion> solicituds;
	
	private SolicitudVehiculo solicitudV;
	private List<SolicitudVehiculo> solicitudsV;
	private SolicitudVehiculo solicitudVselect;
	
	private String filterName;
	
	@PostConstruct
	public void init() {
		vehiculo = new Vehiculo();
		vehiculos = new ArrayList<Vehiculo>();

		solicitud = new SolicitudRenovacion();
		solicituds = new ArrayList<>();
		
		solicitudV = new SolicitudVehiculo();
		solicitudsV = new ArrayList<>();

		getAllSolicitudsV();
	}
	public void getAllSolicitudsV() {
		try {
			solicitudsV = solicitudVBusiness.getAll();
		} catch (Exception e) {
			Message.messageError("Error Carga de Productos :" + e.getMessage());
		}
	}
	public String newSolicitudV() {

		try {
			this.vehiculos = vehiculoBusiness.getAll();
			this.solicituds = solicitudRBusiness.getAll();
			resetForm();
		} catch (Exception e) {
			// TODO: handle exception
		}

		return "insertSolicitud.xhtml";
	}
	public String listProduct() {
		return "listSolicitud.xhtml";
	}
	public String saveSolicitudV() {
		String view = "";
		try {

			if (solicitudV.getId() != null) {
				solicitudV.setSolicitud(solicitud);
				solicitudV.setVehiculo(vehiculo);
				solicitudVBusiness.update(solicitudV);
				Message.messageInfo("Registro actualizado exitosamente");
			} else {
				solicitudV.setSolicitud(solicitud);
				solicitudV.setVehiculo(vehiculo);
				solicitudVBusiness.insert(solicitudV);
				Message.messageInfo("Registro guardado exitosamente");

			}
			this.getAllSolicitudsV();
			resetForm();
			view = "list";
		} catch (Exception e) {
			Message.messageError("Error solicitud :" + e.getStackTrace());
		}

		return view;
	}
	public String editProduct() {
		String view = "";
		try {
			if (this.solicitudVselect != null) {
				this.solicitudV = solicitudVselect;

				view = "/solicitud/update";
			} else {
				Message.messageInfo("Debe seleccionar un producto");
			}
		} catch (Exception e) {
			Message.messageError("Error Product :" + e.getMessage());
		}

		return view;
	}
	public void searchProductByName() {
		try {

			solicitudsV = solicitudVBusiness.getSolicitudsByName(this.filterName.trim());
			resetForm();
			if (solicitudsV.isEmpty()) {
				Message.messageInfo("No se encontraron productos");

			}

		} catch (Exception e) {
			Message.messageError("Error Product Search :" + e.getMessage());
		}
	}
	public void selectSolicitudV(SelectEvent e) {
		this.solicitudVselect = (SolicitudVehiculo) e.getObject();
	}

	public void resetForm() {
		this.filterName = "";
		this.solicitudV = new SolicitudVehiculo();
	}
	public VehiculoBusiness getVehiculoBusiness() {
		return vehiculoBusiness;
	}
	public void setVehiculoBusiness(VehiculoBusiness vehiculoBusiness) {
		this.vehiculoBusiness = vehiculoBusiness;
	}
	public SolicitudVehiculoBusiness getSolicitudVBusiness() {
		return solicitudVBusiness;
	}
	public void setSolicitudVBusiness(SolicitudVehiculoBusiness solicitudVBusiness) {
		this.solicitudVBusiness = solicitudVBusiness;
	}
	public SolicitudRenovacionBusiness getSolicitudRBusiness() {
		return solicitudRBusiness;
	}
	public void setSolicitudRBusiness(SolicitudRenovacionBusiness solicitudRBusiness) {
		this.solicitudRBusiness = solicitudRBusiness;
	}
	public Vehiculo getVehiculo() {
		return vehiculo;
	}
	public void setVehiculo(Vehiculo vehiculo) {
		this.vehiculo = vehiculo;
	}
	public List<Vehiculo> getVehiculos() {
		return vehiculos;
	}
	public void setVehiculos(List<Vehiculo> vehiculos) {
		this.vehiculos = vehiculos;
	}
	public SolicitudRenovacion getSolicitud() {
		return solicitud;
	}
	public void setSolicitud(SolicitudRenovacion solicitud) {
		this.solicitud = solicitud;
	}
	public List<SolicitudRenovacion> getSolicituds() {
		return solicituds;
	}
	public void setSolicituds(List<SolicitudRenovacion> solicituds) {
		this.solicituds = solicituds;
	}
	public SolicitudVehiculo getSolicitudV() {
		return solicitudV;
	}
	public void setSolicitudV(SolicitudVehiculo solicitudV) {
		this.solicitudV = solicitudV;
	}
	public List<SolicitudVehiculo> getSolicitudsV() {
		return solicitudsV;
	}
	public void setSolicitudsV(List<SolicitudVehiculo> solicitudsV) {
		this.solicitudsV = solicitudsV;
	}
	public SolicitudVehiculo getSolicitudVselect() {
		return solicitudVselect;
	}
	public void setSolicitudVselect(SolicitudVehiculo solicitudVselect) {
		this.solicitudVselect = solicitudVselect;
	}
	public String getFilterName() {
		return filterName;
	}
	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
