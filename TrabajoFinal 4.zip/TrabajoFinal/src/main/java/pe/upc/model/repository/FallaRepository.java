package pe.upc.model.repository;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import pe.upc.model.entity.Falla;

@Named
public class FallaRepository implements Serializable{
	private static final long serialVersionUID = 1L;

	@PersistenceContext(unitName = "pwPU")
	private EntityManager em;
	
	public List<Falla> findAll() throws Exception {
		List<Falla> fallas = new ArrayList<>();

		TypedQuery<Falla> query = em.createQuery("SELECT s FROM Falla s", Falla.class);
		fallas = query.getResultList();
		return fallas;
	}
	
	public Long insert(Falla falla) throws Exception {
		em.persist(falla);
		return falla.getFalla_id();
	}
	
	public Long update(Falla falla) throws Exception {
		em.merge(falla);
		return falla.getFalla_id();
	}
	public List<Falla> findByName(String name) throws Exception {
		List<Falla> fallas = new ArrayList<>();

		TypedQuery<Falla> query = em.createQuery("FROM Falla p WHERE p.nombre LIKE ?1", Falla.class);
		query.setParameter(1, "%" + name + "%");
		fallas = query.getResultList();

		return fallas;
	}
}
