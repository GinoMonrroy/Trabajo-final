package pe.upc.model.repository;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import pe.upc.model.entity.SolicitudVehiculo;

@Named
public class SolicitudVehiculoRepository implements Serializable{
	private static final long serialVersionUID = 1L;

	@PersistenceContext(unitName = "pwPU")
	private EntityManager em;
	
	public Long insert(SolicitudVehiculo solicitud) throws Exception {
		em.persist(solicitud);
		return solicitud.getId();
	}
	
	public Long update(SolicitudVehiculo solicitud) throws Exception {
		em.merge(solicitud);
		return solicitud.getId();
	}
	public List<SolicitudVehiculo> findAll() throws Exception {
		List<SolicitudVehiculo> solicituds = new ArrayList<>();

		TypedQuery<SolicitudVehiculo> query = em.createQuery("FROM SolicitudVehiculo p", SolicitudVehiculo.class);
		solicituds = query.getResultList();

		return solicituds;
	}
	public List<SolicitudVehiculo> findByName(String name) throws Exception {
		List<SolicitudVehiculo> solicitud = new ArrayList<>();

		TypedQuery<SolicitudVehiculo> query = em.createQuery("FROM SolicitudVehiculo p WHERE p.id LIKE ?1", SolicitudVehiculo.class);
		query.setParameter(1, "%" + name + "%");
		solicitud = query.getResultList();

		return solicitud;
	}
}
